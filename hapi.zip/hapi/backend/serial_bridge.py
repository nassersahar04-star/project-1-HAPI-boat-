"""Optional USB serial bridge: ESP32 JSON lines -> FastAPI telemetry API.
Run: python serial_bridge.py --port COM3 --baud 115200
"""
import argparse, json, urllib.request
import serial
def main():
 p=argparse.ArgumentParser();p.add_argument('--port',required=True);p.add_argument('--baud',type=int,default=115200);p.add_argument('--url',default='http://127.0.0.1:8000/api/telemetry');a=p.parse_args()
 with serial.Serial(a.port,a.baud,timeout=2) as ser:
  print(f'Reading {a.port} at {a.baud}; Ctrl+C to stop')
  while True:
   line=ser.readline().decode('utf-8','replace').strip()
   if not line: continue
   try:
    payload=json.loads(line)
    req=urllib.request.Request(a.url,data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'},method='POST')
    with urllib.request.urlopen(req,timeout=3) as r: print(r.status,payload.get('boat_id'),payload.get('boat_status'))
   except Exception as e: print('Skipped line:',e)
if __name__=='__main__': main()
