
from fastapi import FastAPI, HTTPException, Request, Response, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import sqlite3, os, secrets, hashlib, hmac, json, time, re
from pathlib import Path

ROOT=Path(__file__).resolve().parent
DB=ROOT/'hapi.db'
SECRET=os.environ.get('HAPI_SECRET','change-this-local-secret')
app=FastAPI(title='HAPI Fleet API',version='1.0.0')
app.mount('/assets',StaticFiles(directory=ROOT/'static'/'assets'),name='assets')

ROLES={'Super Admin','Admin','HSE','Operator'}
STATUSES={'IDLE','MOVING_FORWARD','MOVING_BACKWARD','TURNING_LEFT','TURNING_RIGHT','STOPPED','COLLECTING_FORWARD'}
COMMANDS={'F','B','L','R','S','C'}
class LiveClients:
 def __init__(self): self.clients=[]
 async def connect(self,ws):
  await ws.accept(); self.clients.append(ws)
 def disconnect(self,ws):
  if ws in self.clients:self.clients.remove(ws)
 async def broadcast(self,payload):
  dead=[]
  for ws in self.clients:
   try: await ws.send_json(payload)
   except Exception: dead.append(ws)
  for ws in dead:self.disconnect(ws)
live=LiveClients()
def db():
 c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;return c
def hashpw(pw,salt=None):
 salt=salt or secrets.token_hex(16)
 digest=hashlib.pbkdf2_hmac('sha256',pw.encode(),salt.encode(),180000).hex()
 return salt+':'+digest
def checkpw(pw,stored):
 try:
  salt,d=stored.split(':',1)
  return hmac.compare_digest(hashpw(pw,salt).split(':',1)[1],d)
 except: return False
def init():
 with db() as c:
  c.execute('CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL, role TEXT NOT NULL)')
  c.execute('CREATE TABLE IF NOT EXISTS telemetry(id INTEGER PRIMARY KEY, received REAL NOT NULL, payload TEXT NOT NULL)')
  c.execute('CREATE TABLE IF NOT EXISTS commands(id INTEGER PRIMARY KEY, command TEXT NOT NULL, created REAL NOT NULL)')
  # Seed the four starter accounts individually; existing users are preserved.
  starter=[('superadmin','Hapi@12345','Super Admin'),('admin','Admin@12345','Admin'),('hse','HSE@12345','HSE'),('operator','Operator@12345','Operator')]
  for username,password,role in starter:
   if not c.execute('SELECT 1 FROM users WHERE username=?',(username,)).fetchone():
    c.execute('INSERT INTO users(username,password,role) VALUES(?,?,?)',(username,hashpw(password),role))
init()
def token(user):
 data=json.dumps({'uid':user['id'],'exp':int(time.time())+12*3600},separators=(',',':')).encode()
 import base64
 body=base64.urlsafe_b64encode(data).decode().rstrip('=')
 sig=hmac.new(SECRET.encode(),body.encode(),hashlib.sha256).hexdigest()
 return body+'.'+sig
def get_user(req):
 t=req.cookies.get('hapi_session','')
 try:
  body,sig=t.split('.',1)
  if not hmac.compare_digest(sig,hmac.new(SECRET.encode(),body.encode(),hashlib.sha256).hexdigest()): raise ValueError()
  import base64
  data=json.loads(base64.urlsafe_b64decode(body+'='*((4-len(body)%4)%4)))
  if data['exp']<time.time(): raise ValueError()
  with db() as c: u=c.execute('SELECT id,username,role FROM users WHERE id=?',(data['uid'],)).fetchone()
  if not u: raise ValueError()
  return dict(u)
 except: raise HTTPException(401,'Please sign in')
def need(req,*roles):
 u=get_user(req)
 if u['role'] not in roles: raise HTTPException(403,'Access denied')
 return u
class Login(BaseModel):
 username:str
 password:str
class NewUser(BaseModel):
 username:str
 password:str
 role:str
class Telemetry(BaseModel):
 boat_id:str
 battery_level:float
 weight:float
 trash_weight_kg:float=0
 lat:float
 lng:float
 boat_status:str
 def validate_contract(self):
  if not 0<=self.battery_level<=100: raise HTTPException(422,'battery_level must be between 0 and 100')
  if self.weight<0 or self.trash_weight_kg<0: raise HTTPException(422,'weights cannot be negative')
  if self.boat_status not in STATUSES: raise HTTPException(422,'Invalid boat_status')
class Command(BaseModel):
 command:str
@app.get('/')
def home(): return FileResponse(ROOT/'static'/'index.html')
@app.post('/api/auth/login')
def login(x:Login,response:Response):
 with db() as c: u=c.execute('SELECT * FROM users WHERE username=?',(x.username,)).fetchone()
 if not u or not checkpw(x.password,u['password']): raise HTTPException(401,'Invalid username or password')
 response.set_cookie('hapi_session',token(u),httponly=True,samesite='lax',max_age=43200)
 return {'id':u['id'],'username':u['username'],'role':u['role']}
@app.get('/api/auth/me')
def me(request:Request): return get_user(request)
@app.post('/api/auth/logout')
def logout(response:Response):
 response.delete_cookie('hapi_session');return {'status':'ok'}
@app.get('/api/users')
def users(request:Request):
 need(request,'Super Admin')
 with db() as c: return [dict(r) for r in c.execute('SELECT id,username,role FROM users ORDER BY id')]
@app.post('/api/users')
def create_user(x:NewUser,request:Request):
 need(request,'Super Admin')
 username=x.username.strip()
 if x.role not in ROLES or not re.fullmatch(r'[A-Za-z0-9_.-]{3,32}',username): raise HTTPException(400,'Username must be 3-32 characters: letters, numbers, dot, underscore, or hyphen')
 if len(x.password)<8: raise HTTPException(400,'Password must be at least 8 characters')
 try:
  with db() as c:c.execute('INSERT INTO users(username,password,role) VALUES(?,?,?)',(username,hashpw(x.password),x.role))
 except sqlite3.IntegrityError: raise HTTPException(409,'Username already exists')
 return {'status':'created'}
@app.delete('/api/users/{uid}')
def delete_user(uid:int,request:Request):
 u=need(request,'Super Admin')
 if uid==u['id']: raise HTTPException(400,'You cannot delete your own account')
 with db() as c:
  target=c.execute('SELECT role FROM users WHERE id=?',(uid,)).fetchone()
  if not target: raise HTTPException(404,'User not found')
  if target['role']=='Super Admin' and c.execute("SELECT COUNT(*) FROM users WHERE role='Super Admin'").fetchone()[0]<=1: raise HTTPException(400,'Cannot delete the last Super Admin')
  c.execute('DELETE FROM users WHERE id=?',(uid,))
 return {'status':'deleted'}
@app.post('/api/telemetry')
async def telemetry(x:Telemetry,request:Request):
 # ESP32/serial bridge ingestion is permitted without browser login; dashboard read access remains role-gated.
 x.validate_contract()
 with db() as c:c.execute('INSERT INTO telemetry(received,payload) VALUES(?,?)',(time.time(),x.model_dump_json()))
 await live.broadcast(x.model_dump())
 return {'status':'ok'}
@app.get('/api/telemetry/latest')
def latest(request:Request):
 need(request,'Super Admin','Admin','HSE','Operator')
 with db() as c:r=c.execute('SELECT payload FROM telemetry ORDER BY id DESC LIMIT 1').fetchone()
 return json.loads(r['payload']) if r else {}
@app.get('/api/telemetry/history')
def history(request:Request,limit:int=100):
 need(request,'Super Admin','Admin','HSE')
 with db() as c:rows=c.execute('SELECT payload FROM telemetry ORDER BY id DESC LIMIT ?', (min(limit,1000),)).fetchall()
 return [json.loads(r['payload']) for r in rows]
@app.post('/api/commands')
def command(x:Command,request:Request):
 need(request,'Super Admin','Admin','Operator')
 if x.command not in ['F','B','L','R','S','C']:raise HTTPException(400,'Unsupported command')
 with db() as c:c.execute('INSERT INTO commands(command,created) VALUES(?,?)',(x.command,time.time()))
 return {'status':'queued'}
@app.get('/api/commands/pending')
def pending(request:Request):
 need(request,'Super Admin','Admin','Operator')
 with db() as c:
  r=c.execute('SELECT id,command FROM commands ORDER BY id LIMIT 1').fetchone()
  if not r:return {'command':None}
  c.execute('DELETE FROM commands WHERE id=?',(r['id'],))
 return {'command':r['command']}
@app.websocket('/ws/live')
async def websocket_live(ws:WebSocket):
 # Same-origin session cookie is used for browser dashboard authorization.
 try:
  user=get_user(ws)
  if user['role'] not in {'Super Admin','Admin','HSE','Operator'}:
   await ws.close(code=1008); return
 except Exception:
  await ws.close(code=1008); return
 await live.connect(ws)
 try:
  latest_data={}
  with db() as c:r=c.execute('SELECT payload FROM telemetry ORDER BY id DESC LIMIT 1').fetchone()
  if r: latest_data=json.loads(r['payload'])
  if latest_data: await ws.send_json(latest_data)
  while True: await ws.receive_text()
 except WebSocketDisconnect: pass
 except Exception: pass
 finally: live.disconnect(ws)
@app.get('/api/health')
def health():return {'status':'healthy'}

