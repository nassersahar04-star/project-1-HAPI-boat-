@echo off
setlocal
cd /d "%~dp0backend"
if not exist ".venv\Scripts\python.exe" (
  echo First-time setup: creating Python environment...
  py -3 -m venv .venv
  if errorlevel 1 (echo Python 3.11+ is required. Install Python and try again.& pause& exit /b 1)
)
".venv\Scripts\python.exe" -m pip install -q -r requirements.txt
if errorlevel 1 (echo Dependency installation failed.& pause& exit /b 1)
start "" http://127.0.0.1:8000
".venv\Scripts\python.exe" -m uvicorn main:app --host 127.0.0.1 --port 8000
pause
