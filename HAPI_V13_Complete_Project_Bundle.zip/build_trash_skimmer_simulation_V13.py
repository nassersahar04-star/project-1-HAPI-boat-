"""V13 HAPI trash-skimmer presentation + engineering simulation builder for Blender.

Creates a colored V12 boat in a walled test pool, bakes a lawn-mower sweep,
models differential motor RPM steering, visual rotating mechanisms, IR wall
range proxies, and proximity-triggered trash transfer into a limited basket.

This is a deterministic, kinematic engineering animation scaffold. It is NOT
CFD, a rigid-body water simulation, or a validated hydrodynamics result. Motor
thrust/yaw relationships are editable assumptions and should be calibrated
against the actual motors, propellers, mass and prototype tests.
"""
import bpy, math, os, csv, random
from mathutils import Vector, Quaternion, Matrix, Euler

# ---------------- USER SETTINGS ----------------
WATERWHEEL_STL_NAME = "trash_skimmer_V12_waterwheel_static_body.stl"
CONVEYOR_STL_NAME = "trash_skimmer_V12_conveyor_static_body.stl"
VARIANT = "conveyor"  # set to "waterwheel" for the paddle-wheel alternative
SOURCE_STL_OVERRIDE = ""  # optional full path to a V12 static-body STL

FPS = 24
CRUISE_SPEED_M_S = 0.22              # assumed demonstration speed, not measured
MAX_MOTOR_RPM = 13000.0              # provisional earlier motor specification; verify loaded RPM
MAX_YAW_RATE_RAD_S = 0.62            # prescribed route yaw-rate cap; kinematic model only
TRACK_WIDTH_M = 0.192               # pontoon centreline spacing: +/-96 mm from CAD
PROP_RPM_RATIO = 0.05               # provisional motor-RPM to prop-RPM ratio; confirm gearing/loaded RPM
MAX_PROP_RPM = MAX_MOTOR_RPM * PROP_RPM_RATIO
M_PER_PROP_RPM = CRUISE_SPEED_M_S / max(MAX_PROP_RPM, 1.0)
VISUAL_PROP_SPIN_SCALE = 0.45       # spin slower than model prop RPM so rotation reads clearly
# Legacy scale removed: use VISUAL_PROP_SPIN_SCALE on modeled propeller RPM only.
IR_MAX_RANGE_M = 0.90                # deliberately extended proxy range
IR_TURN_TRIGGER_M = 0.32              # begin turn response when front sensor is inside this range
IR_SIDE_WARNING_M = 0.36
WATER_DENSITY_KG_M3 = 997.3
BOAT_MASS_KG_ASSUMED = 0.45  # whole-boat placeholder; replace with a scale measurement           # placeholder until assembled boat is weighed
PETG_DENSITY_KG_M3_ASSUMED = 1270.0   # nominal visual/material assumption; actual print mass depends on infill
MAX_TRASH_ITEMS = 20
MAX_TRASH_MASS_KG = 0.050             # provisional capacity limit; NOT a buoyancy/stability certification
TRASH_COUNT = 20
TRASH_TRANSFER_SECONDS = 0.9
POOL_LENGTH_M = 4.20
POOL_WIDTH_M = 4.20  # V13 polish: square pool enlarged for a longer multi-lane sweep
POOL_WALL_HEIGHT_M = 0.52
POOL_WALL_THICKNESS_M = 0.06
POOL_FLOOR_Z = -0.12
WATER_Z = 0.062
WALL_CLEARANCE_M = 0.18
LANE_SPACING_M = 0.23

# ---------------- PATH DISCOVERY ----------------
def candidate_dirs():
    dirs=[]
    try:
        if "__file__" in globals(): dirs.append(os.path.dirname(os.path.abspath(__file__)))
    except Exception: pass
    try:
        area = bpy.context.space_data
        if area and area.type == 'TEXT_EDITOR' and area.text and area.text.filepath:
            dirs.append(os.path.dirname(bpy.path.abspath(area.text.filepath)))
    except Exception: pass
    try:
        if bpy.data.filepath: dirs.append(os.path.dirname(bpy.data.filepath))
    except Exception: pass
    dirs.extend([os.getcwd(), os.path.expanduser("~")])
    out=[]
    for d in dirs:
        if d and d not in out: out.append(d)
    return out

SCRIPT_DIR = next((d for d in candidate_dirs() if os.path.exists(os.path.join(d, WATERWHEEL_STL_NAME)) or os.path.exists(os.path.join(d, CONVEYOR_STL_NAME))),
                  candidate_dirs()[0] if candidate_dirs() else os.getcwd())
SOURCE_NAME = CONVEYOR_STL_NAME if VARIANT.lower() == "conveyor" else WATERWHEEL_STL_NAME
SOURCE_STL = bpy.path.abspath(SOURCE_STL_OVERRIDE) if SOURCE_STL_OVERRIDE else os.path.join(SCRIPT_DIR, SOURCE_NAME)
PARTS_DIR = os.path.join(SCRIPT_DIR, "trash_skimmer_V12_parts", VARIANT.lower())
OUTPUT_BLEND = os.path.join(SCRIPT_DIR, f"HAPI_trash_skimmer_V13_{VARIANT}_pool_simulation.blend")
OUTPUT_TELEMETRY = os.path.join(SCRIPT_DIR, f"HAPI_V13_{VARIANT}_simulation_telemetry.csv")
OUTPUT_SUMMARY = os.path.join(SCRIPT_DIR, f"HAPI_V13_{VARIANT}_simulation_summary.csv")
OUTPUT_COMPONENT_BUDGET = os.path.join(SCRIPT_DIR, f"HAPI_V13_{VARIANT}_component_mass_current_budget.csv")
OUTPUT_MASS_CURRENT = os.path.join(SCRIPT_DIR, f"HAPI_V13_{VARIANT}_mass_current_telemetry.csv")
# Editable electrical assumptions for a scenario illustration, not a final wiring recommendation.
SUPPLY_VOLTAGE_V = 12.0
PROPULSION_MOTOR_RATED_POWER_W = 80.0  # user-supplied component list; assume electrical input only for this estimate
PROPULSION_MOTOR_COUNT = 2
ACCESSORY_CURRENT_A_ASSUMED = 1.8  # servo/controller/sensors/collector rough allowance; replace with datasheet values
MOTOR_NOMINAL_CURRENT_A = PROPULSION_MOTOR_RATED_POWER_W / SUPPLY_VOLTAGE_V
TOTAL_RATED_CURRENT_A_ASSUMED = PROPULSION_MOTOR_COUNT * MOTOR_NOMINAL_CURRENT_A + ACCESSORY_CURRENT_A_ASSUMED
CAMERA_MODE = "FOLLOW"  # change to "OVERVIEW" to render the full square pool instead
RENDER_PRESET = "BALANCED"  # balanced for midrange GPUs; raise resolution_percentage for final polish


if not os.path.exists(SOURCE_STL):
    looked = "\n".join(os.path.join(d, SOURCE_NAME) for d in candidate_dirs())
    raise FileNotFoundError("V12 static-body STL not found. Extract the complete V12 package and keep trash_skimmer_V12_parts beside this script, or set SOURCE_STL_OVERRIDE.\nLooked in:\n" + looked)
if not os.path.isdir(PARTS_DIR):
    raise FileNotFoundError("Named V12 moving-part assets not found: " + PARTS_DIR + ". Extract the entire ZIP, including the trash_skimmer_V12_parts folder.")

# ---------------- SCENE RESET ----------------
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
scene = bpy.context.scene
for child in list(scene.collection.children):
    # Keep Blender's default active Collection so object-adding operators retain a valid context.
    if child.name == "Collection":
        continue
    try:
        scene.collection.children.unlink(child)
        bpy.data.collections.remove(child)
    except Exception: pass
for block in list(bpy.data.materials):
    if block.users == 0:
        bpy.data.materials.remove(block)

scene.frame_start = 1
scene.render.fps = FPS
scene.render.resolution_x = 1280
scene.render.resolution_y = 720
scene.render.resolution_percentage = 80 if RENDER_PRESET.upper()=="BALANCED" else 45
try: scene.render.engine = 'BLENDER_EEVEE_NEXT'
except Exception:
    try: scene.render.engine = 'BLENDER_EEVEE'
    except Exception: scene.render.engine = 'CYCLES'
if hasattr(scene, 'eevee'):
    try: scene.eevee.taa_render_samples = 24 if RENDER_PRESET.upper()=="BALANCED" else 8
    except Exception: pass
    try: scene.eevee.taa_samples = 16 if RENDER_PRESET.upper()=="BALANCED" else 8
    except Exception: pass
    try: scene.eevee.use_gtao = True
    except Exception: pass
scene.world.color = (0.025, 0.04, 0.06)
# Render directly to an H.264 movie with Ctrl+F12 / Render Animation.
scene.render.image_settings.file_format = 'FFMPEG'
try:
    scene.render.ffmpeg.format = 'MPEG4'
    scene.render.ffmpeg.codec = 'H264'
    scene.render.ffmpeg.constant_rate_factor = 'MEDIUM'
    scene.render.ffmpeg.ffmpeg_preset = 'GOOD'
    scene.render.ffmpeg.gopsize = FPS
    scene.render.ffmpeg.video_bitrate = 12000
except Exception: pass
scene.render.use_file_extension = True
scene.view_settings.view_transform = 'AgX'

# ---------------- COLLECTIONS / HELPERS ----------------
def collection(name):
    col=bpy.data.collections.new(name); scene.collection.children.link(col); return col
COL_CAD = collection("01 | V12 static CAD body (colored, original geometry)")
COL_CAD_MOVING = collection("01b | V12 named moving CAD parts (real exported meshes)")
COL_POOL = collection("02 | Controlled pool and water")
COL_DRIVE = collection("03 | Rear motors, shafts, propellers and rudders")
COL_PICKUP = collection("04 | Trash pickup mechanism (active variant)")
COL_SENSORS = collection("05 | IR sensors and range beams")
COL_TRASH = collection("06 | Floating trash and basket load")
COL_ROUTE = collection("07 | Lawn-mower route and annotations")
COL_STAGE = collection("08 | Camera and lighting")

def link_to(obj, col):
    for c in list(obj.users_collection):
        try: c.objects.unlink(obj)
        except Exception: pass
    col.objects.link(obj)
    return obj

def material(name, color, metallic=0.0, roughness=0.36, alpha=1.0, emission=0.0):
    m=bpy.data.materials.new(name); m.diffuse_color=(*color, alpha); m.use_nodes=True
    bsdf=m.node_tree.nodes.get('Principled BSDF')
    bsdf.inputs['Base Color'].default_value=(*color, alpha)
    bsdf.inputs['Metallic'].default_value=metallic
    bsdf.inputs['Roughness'].default_value=roughness
    if alpha < 1.0:
        try:
            bsdf.inputs['Alpha'].default_value=alpha
            m.surface_render_method='DITHERED'
        except Exception: pass
    if emission:
        try:
            bsdf.inputs['Emission Color'].default_value=(*color, 1.0)
            bsdf.inputs['Emission Strength'].default_value=emission
        except Exception: pass
    return m

MAT_HULL=material("HAPI hull | clean white PETG appearance",(0.88,0.92,0.94),0.02,0.30)
MAT_PONTOON=material("HAPI pontoons | deep river navy blue",(0.012,0.055,0.19),0.08,0.27)
MAT_FRAME=material("Frame | satin graphite",(0.075,0.095,0.12),0.24,0.34)
MAT_COMPONENT=material("Electronics enclosures | warm light grey",(0.77,0.80,0.82),0.04,0.38)
MAT_SOLAR=material("Roof / solar panel | HAPI blue-black",(0.018,0.065,0.15),0.22,0.25)
MAT_MECH=material("Mechanical parts | matte black polymer",(0.014,0.017,0.022),0.0,0.64)
MAT_PROP=material("Propellers | matte black",(0.008,0.010,0.013),0.0,0.72)
MAT_METAL=material("Shafts and fasteners | satin dark steel",(0.09,0.12,0.15),0.48,0.36)
MAT_WATER=material("Pool water | deep teal with procedural normals",(0.012,0.145,0.215),0.04,0.19,1.0)
MAT_POOL=material("Pool wall | pale blue concrete",(0.47,0.62,0.66),0.0,0.6)
MAT_POOL_INNER=material("Pool lining",(0.10,0.25,0.30),0.0,0.58)
MAT_IR=material("IR beam | subtle amber",(1.0,0.56,0.05),0.0,0.35,0.45,0.20)
MAT_LOGO=material("HAPI side mark | cool white",(0.72,0.92,1.0),0.0,0.54,1.0,0.0)
MAT_FOAM=material("Prop wash | pale cyan foam",(0.64,0.89,0.96),0.02,0.25,0.68,0.05)
MAT_WAKE=material("Local wake rings | pale cyan",(0.25,0.68,0.78),0.0,0.30,0.24,0.0)
MAT_TRASH=[material("Trash | orange wrapper",(0.96,0.25,0.035),0.0,0.52),
           material("Trash | yellow plastic",(0.93,0.68,0.08),0.0,0.50),
           material("Trash | green fragment",(0.045,0.48,0.18),0.0,0.50),
           material("Trash | pale bottle",(0.75,0.88,0.87),0.0,0.31)]
# Animate subtle water-surface normals using procedural noise; inexpensive in Eevee.
try:
    _nodes=MAT_WATER.node_tree.nodes; _links=MAT_WATER.node_tree.links
    _bsdf=_nodes.get('Principled BSDF')
    _tex=_nodes.new('ShaderNodeTexNoise'); _tex.name='Fine water surface'; _tex.inputs['Scale'].default_value=28.0; _tex.inputs['Detail'].default_value=3.0; _tex.inputs['Roughness'].default_value=0.55
    _coord=_nodes.new('ShaderNodeTexCoord')
    _mapping=_nodes.new('ShaderNodeMapping'); _mapping.name='Subtle water pattern coordinates'
    _wave_tex=_nodes.new('ShaderNodeTexWave'); _wave_tex.name='Long soft wavelets'; _wave_tex.wave_type='BANDS'; _wave_tex.bands_direction='X'; _wave_tex.inputs['Scale'].default_value=5.5; _wave_tex.inputs['Distortion'].default_value=2.2; _wave_tex.inputs['Detail'].default_value=2.0
    _mix=_nodes.new('ShaderNodeMixRGB'); _mix.name='Noise plus wavelets'; _mix.blend_type='MULTIPLY'; _mix.inputs[0].default_value=0.28
    _bump=_nodes.new('ShaderNodeBump'); _bump.inputs['Strength'].default_value=0.28; _bump.inputs['Distance'].default_value=0.0045
    _links.new(_coord.outputs['Generated'],_mapping.inputs['Vector']); _links.new(_mapping.outputs['Vector'],_tex.inputs['Vector']); _links.new(_mapping.outputs['Vector'],_wave_tex.inputs['Vector']); _links.new(_tex.outputs['Fac'],_mix.inputs[1]); _links.new(_wave_tex.outputs['Color'],_mix.inputs[2]); _links.new(_mix.outputs['Color'],_bump.inputs['Height']); _links.new(_bump.outputs['Normal'],_bsdf.inputs['Normal'])
except Exception: pass

# ---------------- IMPORT V12 STATIC BODY + NAMED MOVING CAD PARTS ----------------
def import_stl_objects(filepath, separate_loose=False, name_prefix=None):
    before=set(scene.objects)
    bpy.ops.object.select_all(action='DESELECT')
    try: bpy.ops.wm.stl_import(filepath=filepath)
    except Exception: bpy.ops.import_mesh.stl(filepath=filepath)
    new_objects=[o for o in scene.objects if o not in before and o.type=='MESH']
    if not new_objects:
        new_objects=[o for o in bpy.context.selected_objects if o.type=='MESH']
    if not new_objects:
        raise RuntimeError("STL import returned no meshes: "+filepath)
    for ob in list(new_objects):
        ob.scale=(0.001,0.001,0.001)  # CAD STL units are millimetres
        bpy.ops.object.select_all(action='DESELECT'); ob.select_set(True); bpy.context.view_layer.objects.active=ob
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
        if separate_loose:
            try:
                bpy.ops.object.mode_set(mode='EDIT'); bpy.ops.mesh.select_all(action='SELECT'); bpy.ops.mesh.separate(type='LOOSE'); bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                try: bpy.ops.object.mode_set(mode='OBJECT')
                except Exception: pass
    new_objects=[o for o in scene.objects if o not in before and o.type=='MESH']
    if name_prefix and separate_loose:
        for idx,ob in enumerate(new_objects,1): ob.name=f"{name_prefix}_{idx:03d}"
    return new_objects

static_parts=import_stl_objects(SOURCE_STL, separate_loose=True, name_prefix="V12_static_body_island")
# Load the actual named STL geometry for every moving CAD component. This avoids inventing a second motor,
# shaft, wheel or conveyor in Blender. These assets share the same CAD coordinates as the full STEP assembly.
named_parts=[]
for filename in sorted(os.listdir(PARTS_DIR)):
    if not filename.lower().endswith('.stl'): continue
    part_name=os.path.splitext(filename)[0]
    imported=import_stl_objects(os.path.join(PARTS_DIR,filename), separate_loose=False)
    for ob in imported:
        ob.name=part_name
        ob["V12_named_CAD_part"]=True
        ob["CAD_asset_file"]=filename
        named_parts.append(ob)
parts=static_parts+named_parts
if not parts: raise RuntimeError("No V12 CAD parts found after import.")

# Compute the full CAD envelope from the imported boat body and named moving parts.
coords=[]
for ob in parts:
    for corner in ob.bound_box:
        coords.append(ob.matrix_world @ Vector(corner))
minx=min(v.x for v in coords); maxx=max(v.x for v in coords)
miny=min(v.y for v in coords); maxy=max(v.y for v in coords)
minz=min(v.z for v in coords); maxz=max(v.z for v in coords)
BOAT_LENGTH=maxx-minx; BOAT_WIDTH=maxy-miny; BOAT_HEIGHT=maxz-minz
CX=(minx+maxx)/2.0; CY=(miny+maxy)/2.0; WATER_Z=WATER_Z
HALF_LENGTH=BOAT_LENGTH/2.0; HALF_WIDTH=BOAT_WIDTH/2.0
# Add small allowance for steering fins/linkage not part of the exported V12 static-body STL.
MAX_HALF_EXTENT=math.sqrt((HALF_LENGTH+0.045)**2+(HALF_WIDTH+0.006)**2)

for i,ob in enumerate(parts,1):
    dims=ob.dimensions.copy()
    world_center=sum((ob.matrix_world @ Vector(c) for c in ob.bound_box), Vector((0.0,0.0,0.0)))/8.0
    name=ob.name
    if ob.get("V12_named_CAD_part"):
        low=name.lower()
        if 'propeller_' in low and 'blade' in low:
            mat=MAT_PROP; category="matte-black propeller blade"
        elif low.startswith('propulsion_motor') or 'shaft' in low or 'hub' in low or 'bearing' in low or 'roller' in low:
            mat=MAT_METAL if ('shaft' in low or 'bearing' in low) else MAT_MECH; category="named moving CAD mechanical component"
        elif 'blade' in low or '_fin_' in low or 'outer_rim' in low or 'spoke_' in low or 'belt_loop' in low:
            mat=MAT_PROP if ('blade' in low or '_fin_' in low) else MAT_MECH; category="named collector/propeller CAD component"
        elif 'guide' in low or 'stringer' in low or 'brace' in low or 'support' in low:
            mat=MAT_FRAME; category="named support CAD component"
        else:
            mat=MAT_COMPONENT; category="named moving CAD component"
        ob.data.materials.clear(); ob.data.materials.append(mat)
        ob["visual_color_category"]=category
        ob["assumed_base_material"]="PETG provisional for printed parts; metal hardware not specified"
    else:
        # The pontoon shell and its internal rib cage are long and have a substantial Y/Z cross-section.
        if dims.x>0.38 and 0.050<dims.y<0.090 and 0.050<dims.z<0.090 and abs(world_center.y)>0.060 and world_center.z<0.12:
            mat=MAT_PONTOON; category="dark-blue pontoon shell / internal ribs"
        elif dims.z<0.018 and dims.x>0.15 and dims.y>0.10 and world_center.z>0.24:
            mat=MAT_SOLAR; category="deep-blue roof/solar panel"
        elif dims.x>0.25 and dims.y>0.10 and dims.z>0.045 and world_center.z<0.24:
            mat=MAT_HULL; category="white central hull/body"
        elif 0.035<dims.x<0.19 and 0.025<dims.y<0.16 and dims.z>0.018 and world_center.z>0.06:
            mat=MAT_COMPONENT; category="enclosure/utility component"
        elif dims.z<0.018 and dims.x>0.15 and dims.y>0.10:
            mat=MAT_HULL; category="white deck panel"
        else:
            mat=MAT_FRAME; category="frame, basket, shim, or structural component"
        ob.data.materials.clear(); ob.data.materials.append(mat)
        ob["CAD_source"]="V12 static-body STL loose mesh island"
        ob["visual_color_category"]=category
        ob["assumed_base_material"]="PETG provisional; metal hardware and infill not confirmed"



# Boat root origin at the original model centre near the waterline. Moving/rotating it moves every CAD part.
bpy.ops.object.empty_add(type='PLAIN_AXES', location=(CX,CY,WATER_Z))
boat_root=bpy.context.object; boat_root.name="BOAT_ROOT | lawn-mower controller output"; link_to(boat_root,COL_CAD)
boat_root["role"]="Parent of original V12 CAD geometry. Its transform is the simulated boat pose."
boat_root["sim_baseline_loc"]=(CX,CY,WATER_Z)
boat_root["sim_baseline_rot"]=(0.0,0.0,0.0)
boat_root["hull_material_assumption"]="PETG; density value and total mass are unverified"
def _baseline_matrix(obj):
    loc=obj.get("sim_baseline_loc")
    if loc is None:
        return obj.matrix_world.copy()
    rot=obj.get("sim_baseline_rot",(0.0,0.0,0.0))
    return Matrix.Translation(Vector(loc)) @ Euler(rot,"XYZ").to_matrix().to_4x4()

def parent_keep_world(child,parent):
    # For animated boat/pivot parents, calculate local transforms against their
    # *baseline* pose, not whichever frame Blender last evaluated. This makes
    # proxies stay attached correctly when the root is already animated.
    mw=child.matrix_world.copy()
    base=_baseline_matrix(parent)
    child.parent=parent
    child.matrix_parent_inverse=Matrix.Identity(4)
    child.matrix_basis=base.inverted() @ mw
    return child
for ob in static_parts:
    parent_keep_world(ob,boat_root); link_to(ob,COL_CAD)
for ob in named_parts:
    parent_keep_world(ob,boat_root); link_to(ob,COL_CAD_MOVING)

# ---------------- BASIC GEOMETRY HELPERS ----------------
def add_box(name, location, dimensions, mat, col, rotation=(0,0,0)):
    bpy.ops.mesh.primitive_cube_add(size=1, location=location, rotation=rotation)
    o=bpy.context.object; o.name=name; o.dimensions=dimensions
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    if mat: o.data.materials.append(mat)
    link_to(o,col); return o

def add_cylinder(name, location, radius, depth, mat, col, rotation=(0,0,0), vertices=32):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=location, rotation=rotation)
    o=bpy.context.object; o.name=name
    if mat: o.data.materials.append(mat)
    link_to(o,col); return o

def add_empty(name, location, col, display='PLAIN_AXES', size=0.025):
    bpy.ops.object.empty_add(type=display, location=location)
    o=bpy.context.object; o.name=name; o.empty_display_size=size; link_to(o,col); return o

def add_irregular_litter(name, location, dimensions, thickness, mat, col, seed=1, sides=7):
    """Create a thin irregular, slightly creased floating litter mesh instead of a cube proxy."""
    rng=random.Random(seed)
    dx,dy=dimensions[0],dimensions[1]
    outline=[]
    phase=rng.uniform(-0.15,0.15)
    for i in range(sides):
        a=2.0*math.pi*i/sides+phase
        r=rng.uniform(0.78,1.08)
        outline.append((math.cos(a)*dx*0.5*r, math.sin(a)*dy*0.5*r))
    verts=[]
    # lower rim, uneven upper rim, then a slightly raised/creased top centre
    for x,y in outline: verts.append((x,y,-thickness*0.5))
    for i,(x,y) in enumerate(outline):
        crease=thickness*rng.uniform(0.25,0.60) if i%2==0 else thickness*rng.uniform(0.0,0.18)
        verts.append((x,y,thickness*0.5+crease))
    verts.append((rng.uniform(-dx*0.12,dx*0.12),rng.uniform(-dy*0.12,dy*0.12),thickness*0.5+thickness*0.65))
    center_idx=2*sides
    faces=[]
    # underside ngon, top faceted fan, side walls
    faces.append(tuple(reversed(range(sides))))
    for i in range(sides):
        j=(i+1)%sides
        faces.append((sides+i,sides+j,center_idx))
        faces.append((i,j,sides+j,sides+i))
    mesh=bpy.data.meshes.new(name+'_mesh'); mesh.from_pydata(verts,[],faces); mesh.materials.append(mat); mesh.update()
    ob=bpy.data.objects.new(name,mesh); col.objects.link(ob); ob.location=location
    return ob

def add_curve_line_local(name, start_local, end_local, mat, col, bevel=0.0014):
    curve=bpy.data.curves.new(name+"_curve",'CURVE'); curve.dimensions='3D'; curve.resolution_u=1; curve.bevel_depth=bevel; curve.bevel_resolution=2
    spline=curve.splines.new('POLY'); spline.points.add(1)
    spline.points[0].co=(start_local[0],start_local[1],start_local[2],1)
    spline.points[1].co=(end_local[0],end_local[1],end_local[2],1)
    ob=bpy.data.objects.new(name,curve); col.objects.link(ob); ob.location=(CX,CY,WATER_Z)
    if mat: curve.materials.append(mat)
    parent_keep_world(ob,boat_root)
    return ob

def add_rod_between_world(name, p1, p2, radius, mat, col, parent=boat_root):
    a=Vector(p1); b=Vector(p2); delta=b-a; length=delta.length
    if length<1e-5: return None
    o=add_cylinder(name,(a+b)/2,radius,length,mat,col,vertices=20)
    o.rotation_mode='QUATERNION'; o.rotation_quaternion=Vector((0,0,1)).rotation_difference(delta.normalized())
    parent_keep_world(o,parent)
    return o

def parent_child_preserving(child,parent):
    return parent_keep_world(child,parent)

def rotate2(x,y,theta):
    c=math.cos(theta); s=math.sin(theta)
    return (c*x-s*y, s*x+c*y)

def root_world_xy(u,v): return (CX+u,CY+v)

# ---------------- CONTROLLED POOL WITH FOUR SOLID WALLS ----------------
POOL_HALF_X=POOL_LENGTH_M/2.0; POOL_HALF_Y=POOL_WIDTH_M/2.0
WALL_TOP=0.46
floor_top=POOL_FLOOR_Z+0.06
floor=add_box("POOL | solid bottom and collision boundary",(CX,CY,POOL_FLOOR_Z+0.03),(POOL_LENGTH_M+2*POOL_WALL_THICKNESS_M,POOL_WIDTH_M+2*POOL_WALL_THICKNESS_M,0.06),MAT_POOL,COL_POOL)
floor["boundary_role"]="pool floor visual/solid mesh; water/CFD solver not included"
wall_center_z=(POOL_FLOOR_Z+WALL_TOP)/2.0
wall_height=WALL_TOP-POOL_FLOOR_Z
for nm,x in [("WEST",CX-POOL_HALF_X-POOL_WALL_THICKNESS_M/2),("EAST",CX+POOL_HALF_X+POOL_WALL_THICKNESS_M/2)]:
    wall=add_box("POOL_WALL_"+nm,(x,CY,wall_center_z),(POOL_WALL_THICKNESS_M,POOL_WIDTH_M+2*POOL_WALL_THICKNESS_M,wall_height),MAT_POOL,COL_POOL)
    wall["collision_boundary"]="wall; controller route maintains full-hull clearance"
for nm,y in [("SOUTH",CY-POOL_HALF_Y-POOL_WALL_THICKNESS_M/2),("NORTH",CY+POOL_HALF_Y+POOL_WALL_THICKNESS_M/2)]:
    wall=add_box("POOL_WALL_"+nm,(CX,y,wall_center_z),(POOL_LENGTH_M,POOL_WALL_THICKNESS_M,wall_height),MAT_POOL,COL_POOL)
    wall["collision_boundary"]="wall; controller route maintains full-hull clearance"
# Subdivided water sheet with very small geometric waves + procedural shader normals.
def make_water_surface(name, center, length, width, mat, col, nx=76, ny=76):
    verts=[]; faces=[]
    for j in range(ny):
        y=-width*0.5+width*j/(ny-1)
        for i in range(nx):
            x=-length*0.5+length*i/(nx-1)
            z=0.00135*math.sin(2.4*x+1.8*y)+0.00075*math.sin(4.6*y-1.3*x)
            verts.append((x,y,z))
    for j in range(ny-1):
        for i in range(nx-1):
            a=j*nx+i; b=a+1; c=a+nx+1; d=a+nx
            faces.append((a,b,c,d))
    mesh=bpy.data.meshes.new(name+'_mesh'); mesh.from_pydata(verts,[],faces); mesh.materials.append(mat); mesh.update()
    ob=bpy.data.objects.new(name,mesh); col.objects.link(ob); ob.location=(center[0],center[1],center[2])
    for poly in mesh.polygons: poly.use_smooth=True
    try:
        wave=ob.modifiers.new('Gentle animated surface swell','WAVE')
        wave.height=0.00135; wave.width=0.30; wave.speed=0.08; wave.narrowness=1.15; wave.start_position_x=0.0; wave.start_position_y=0.0
    except Exception: pass
    return ob
water=make_water_surface("WATER_SURFACE | low-cost wave sheet (not CFD)",(CX,CY,WATER_Z-0.002),POOL_LENGTH_M,POOL_WIDTH_M,MAT_WATER,COL_POOL)
water["solver_warning"]="Visual animated surface ripples only; not MantaFlow/CFD and not a buoyancy solver."
water["water_density_kg_m3_assumed"]=WATER_DENSITY_KG_M3

# ---------------- BUILD A LAWN-MOWER COVERAGE ROUTE ----------------
# Route is calculated with margin for hull's diagonal footprint, a turning radius,
# and extra clearance. The front IR sensor observes each wall and logs turn events.
# Pick the maximum symmetric lane count that remains clear of the walls even
# during diagonal hull orientations at U-turns.
lane_count=int(math.floor((2*(POOL_HALF_Y-MAX_HALF_EXTENT-WALL_CLEARANCE_M-0.02))/LANE_SPACING_M))+1
lane_count=max(2,lane_count)
lane_values=[round((i-(lane_count-1)/2.0)*LANE_SPACING_M,4) for i in range(lane_count)]
TRASH_COUNT=lane_count*4
TURN_R=LANE_SPACING_M/2.0
X_END=min(POOL_HALF_X-MAX_HALF_EXTENT-WALL_CLEARANCE_M-TURN_R,
          POOL_HALF_X-(HALF_LENGTH-0.012)-IR_TURN_TRIGGER_M)
X_LEFT=-X_END; X_RIGHT=X_END
ROUTE_SPEED=CRUISE_SPEED_M_S
TURN_SPEED=TURN_R*MAX_YAW_RATE_RAD_S
poses=[{"x":X_RIGHT,"y":lane_values[0],"mode":"sweep"}]
segment_meta=[]
def append_line(x0,y0,x1,y1,speed,mode):
    length=math.hypot(x1-x0,y1-y0)
    n=max(1,int(math.ceil(length/max(speed,1e-5)*FPS)))
    for j in range(1,n+1):
        t=j/n; poses.append({"x":x0+(x1-x0)*t,"y":y0+(y1-y0)*t,"mode":mode})

def append_arc(cx0,cy0,r,a0,a1,speed):
    length=abs(a1-a0)*r
    n=max(2,int(math.ceil(length/max(speed,1e-5)*FPS)))
    for j in range(1,n+1):
        a=a0+(a1-a0)*j/n
        poses.append({"x":cx0+r*math.cos(a),"y":cy0+r*math.sin(a),"mode":"IR_TURN"})

# Each pass covers one lane; semicircular transitions are kept inside the wall-safe envelope.
for lane_i,lane_y in enumerate(lane_values):
    if lane_i%2==0:
        append_line(X_RIGHT,lane_y,X_LEFT,lane_y,ROUTE_SPEED,"sweep")
        if lane_i<len(lane_values)-1:
            y_next=lane_values[lane_i+1]; ymid=(lane_y+y_next)/2.0
            append_arc(X_LEFT,ymid,TURN_R,-math.pi/2,-3*math.pi/2,TURN_SPEED)
    else:
        append_line(X_LEFT,lane_y,X_RIGHT,lane_y,ROUTE_SPEED,"sweep")
        if lane_i<len(lane_values)-1:
            y_next=lane_values[lane_i+1]; ymid=(lane_y+y_next)/2.0
            append_arc(X_RIGHT,ymid,TURN_R,-math.pi/2,math.pi/2,TURN_SPEED)
# Hold at the end so the fully loaded basket and telemetry are visible.
for _ in range(FPS*3): poses.append({"x":poses[-1]["x"],"y":poses[-1]["y"],"mode":"complete"})

# Orientation from each path tangent. Unwrap so rotations animate continuously across +/-pi.
yaw_raw=[]
for i,p in enumerate(poses):
    j=min(i+1,len(poses)-1); k=max(i-1,0)
    dx=poses[j]["x"]-poses[k]["x"]; dy=poses[j]["y"]-poses[k]["y"]
    if math.hypot(dx,dy)<1e-8 and yaw_raw:
        yaw_raw.append(yaw_raw[-1])
    else:
        yaw_raw.append(math.atan2(-dy,-dx))
yaws=[]
for i,a in enumerate(yaw_raw):
    if i==0: yaws.append(a)
    else:
        delta=math.atan2(math.sin(a-yaw_raw[i-1]),math.cos(a-yaw_raw[i-1]))
        yaws.append(yaws[-1]+delta)

# Derive motor RPM outputs from linear speed and yaw rate. The relationship is a
# tunable kinematic model: differential RPM creates yaw, not a validated prop-thrust curve.
telemetry=[]
front_dists=[]; left_dists=[]; right_dists=[]; clearances=[]; sensor_trigger=[]
IR_WORLD_X=0.018
IR_LOCAL_X=IR_WORLD_X-CX
IR_SENSOR_LOCAL=[(IR_LOCAL_X,-0.045,0.028,0.0),(IR_LOCAL_X,0.045,0.028,math.radians(27)),(IR_LOCAL_X,0.0,0.028,math.radians(-27))]
# ray helper against inner rectangular pool bounds
xmin=CX-POOL_HALF_X; xmax=CX+POOL_HALF_X; ymin=CY-POOL_HALF_Y; ymax=CY+POOL_HALF_Y

def ray_rect_distance(ox,oy,dx,dy,max_range):
    ts=[]
    if dx>1e-9: ts.append((xmax-ox)/dx)
    elif dx<-1e-9: ts.append((xmin-ox)/dx)
    if dy>1e-9: ts.append((ymax-oy)/dy)
    elif dy<-1e-9: ts.append((ymin-oy)/dy)
    positive=[t for t in ts if t>=0]
    return min(max_range,min(positive) if positive else max_range)

MAX_RPM=MAX_MOTOR_RPM
for i,p in enumerate(poses):
    frame=i+1; theta=yaws[i]; wx,wy=root_world_xy(p["x"],p["y"])
    if i==0:
        v=0.0; omega=0.0
    else:
        dx=poses[i]["x"]-poses[i-1]["x"]; dy=poses[i]["y"]-poses[i-1]["y"]
        v=math.hypot(dx,dy)*FPS
        omega=(yaws[i]-yaws[i-1])*FPS
    # Differential drive inverse kinematics: port/left and starboard/right propeller linear speeds.
    v_left=v-omega*TRACK_WIDTH_M/2.0
    v_right=v+omega*TRACK_WIDTH_M/2.0
    prop_l=max(-MAX_PROP_RPM,min(MAX_PROP_RPM,v_left/max(M_PER_PROP_RPM,1e-8)))
    prop_r=max(-MAX_PROP_RPM,min(MAX_PROP_RPM,v_right/max(M_PER_PROP_RPM,1e-8)))
    rpm_l=max(-MAX_MOTOR_RPM,min(MAX_MOTOR_RPM,prop_l/max(PROP_RPM_RATIO,1e-8)))
    rpm_r=max(-MAX_MOTOR_RPM,min(MAX_MOTOR_RPM,prop_r/max(PROP_RPM_RATIO,1e-8)))
    v_left_model=prop_l*M_PER_PROP_RPM; v_right_model=prop_r*M_PER_PROP_RPM
    rpm_speed_model=(v_left_model+v_right_model)/2.0
    rpm_yaw_model=(v_right_model-v_left_model)/TRACK_WIDTH_M
    dists=[]
    for lx,ly,lz,ang in IR_SENSOR_LOCAL:
        sx,sy=rotate2(lx,ly,theta); ox=wx+sx; oy=wy+sy
        rayang=theta+ang; dxr=-math.cos(rayang); dyr=-math.sin(rayang)
        dists.append(ray_rect_distance(ox,oy,dxr,dyr,IR_MAX_RANGE_M))
    fd,ld,rd=dists[0],dists[1],dists[2]
    front_dists.append(fd); left_dists.append(ld); right_dists.append(rd)
    active=(fd<=IR_TURN_TRIGGER_M) or (min(ld,rd)<=IR_SIDE_WARNING_M)
    sensor_trigger.append(active)
    clearance_length=BOAT_LENGTH+0.070  # includes simulated rudder and linkage extension
    clearance_width=BOAT_WIDTH+0.012
    hx=0.5*(abs(math.cos(theta))*clearance_length+abs(math.sin(theta))*clearance_width)
    hy=0.5*(abs(math.sin(theta))*clearance_length+abs(math.cos(theta))*clearance_width)
    clearance=min(wx-(xmin+hx), (xmax-hx)-wx, wy-(ymin+hy), (ymax-hy)-wy)
    clearances.append(clearance)
    next_mode=poses[i+1]["mode"] if i+1<len(poses) else "complete"
    if p["mode"]=="IR_TURN": controller_state="DIFFERENTIAL_RPM_TURN"
    elif fd<=IR_TURN_TRIGGER_M and next_mode=="IR_TURN": controller_state="IR_WALL_DETECTED_TURN_QUEUED"
    elif active: controller_state="IR_WALL_WARNING"
    elif p["mode"]=="complete": controller_state="CAPACITY_CHECK_AND_HOLD"
    else: controller_state="LAWN_MOWER_SWEEP"
    telemetry.append({"frame":frame,"time_s":i/FPS,"x_m":wx,"y_m":wy,"yaw_deg":math.degrees(theta),
        "mode":p["mode"],"controller_state":controller_state,"speed_command_m_s":v,
        "speed_from_rpm_model_m_s":rpm_speed_model,"yaw_rate_command_rad_s":omega,
        "yaw_rate_from_rpm_model_rad_s":rpm_yaw_model,"left_motor_rpm_command":rpm_l,"right_motor_rpm_command":rpm_r,
        "left_prop_rpm_model":prop_l,"right_prop_rpm_model":prop_r,
        "left_prop_visual_rpm":prop_l*VISUAL_PROP_SPIN_SCALE,"right_prop_visual_rpm":prop_r*VISUAL_PROP_SPIN_SCALE,
        "front_ir_distance_m":fd,"left_ir_distance_m":ld,"right_ir_distance_m":rd,
        "ir_turn_or_warning":int(active),"minimum_hull_wall_clearance_m":clearance})



# Confirm the planned hull envelope remains inside the pool; fail early if the route violates margin.
min_clearance=min(clearances)
if min_clearance < -1e-5:
    raise RuntimeError(f"Coverage path intersects pool walls: minimum computed hull clearance = {min_clearance:.4f} m")

# Bake root transform for reliable playback across Blender versions.
scene.frame_end=len(poses)
boat_root.rotation_mode='XYZ'
for i,p in enumerate(poses):
    fr=i+1
    boat_root.location=(CX+p["x"],CY+p["y"],WATER_Z)
    boat_root.rotation_euler=(0.0,0.0,yaws[i])
    boat_root.keyframe_insert(data_path='location',frame=fr)
    boat_root.keyframe_insert(data_path='rotation_euler',frame=fr)

# ---------------- ACTUAL CAD PROPULSION + RUDDER PROXIES ----------------
# The two motor housings, shafts, hubs and six broad propeller blades are imported from V12 CAD.
# Only the rudders, linkage and steering servo are new simulation objects; no duplicate motors/props are added.
def cad_mesh_center(obj):
    return sum((Vector(c) for c in obj.bound_box), Vector((0.0,0.0,0.0)))/8.0

def make_local_pivot(name, cad_center, col, display='CIRCLE', size=0.012):
    # cad_center is the absolute CAD coordinate encoded in the imported STL's mesh vertices.
    world=(cad_center.x,cad_center.y,cad_center.z)
    pivot=add_empty(name,world,col,display=display,size=size)
    pivot.parent=boat_root; pivot.matrix_parent_inverse=Matrix.Identity(4)
    pivot.location=(cad_center.x-CX,cad_center.y-CY,cad_center.z-WATER_Z)
    pivot.rotation_mode='XYZ'; pivot.rotation_euler=(0.0,0.0,0.0)
    pivot["sim_baseline_loc"]=world; pivot["sim_baseline_rot"]=(0.0,0.0,0.0)
    return pivot

def reparent_named_mesh_to_pivot(obj,pivot,cad_center):
    # STL mesh vertices are in absolute CAD coordinates; translate by -pivot centre in child space.
    obj.parent=pivot; obj.matrix_parent_inverse=Matrix.Identity(4)
    obj.matrix_basis=Matrix.Translation(Vector((-cad_center.x,-cad_center.y,-cad_center.z)))
    return obj

prop_pivots=[]; prop_hub_centers=[]; prop_motor_objects=[]; rudder_pivots=[]
for side_idx,side in enumerate(("port","starboard")):
    motor=bpy.data.objects.get(f"Propulsion_motor_{side}")
    shaft=bpy.data.objects.get(f"Propulsion_shaft_{side}")
    hub=bpy.data.objects.get(f"Propeller_hub_{side}")
    blades=[bpy.data.objects.get(f"Propeller_{side}_blade_{j}") for j in range(1,4)]
    if not all([motor,shaft,hub,*blades]):
        raise RuntimeError(f"Missing named V12 propulsion CAD parts for {side}; check {PARTS_DIR}")
    motor["role"]="Single propulsion motor mesh imported from V12 CAD; provisional dimensions"
    motor["assumed_motor_rpm"]=MAX_MOTOR_RPM
    prop_center=cad_mesh_center(hub); prop_hub_centers.append(prop_center)
    pivot=make_local_pivot(f"Propeller_{side}_SPIN_PIVOT",prop_center,COL_DRIVE,display='CIRCLE',size=0.012)
    for part in [shaft,hub,*blades]:
        reparent_named_mesh_to_pivot(part,pivot,cad_mesh_center(hub))
        link_to(part,COL_DRIVE)
    link_to(motor,COL_DRIVE)
    prop_pivots.append(pivot); prop_motor_objects.append(motor)

# Add two small rudder fins in the propeller wash and a single linkage/servo; these are intentionally distinct
# steering components, not extra propulsion units. Place rudders just aft of the propeller planes.
for side_idx,side in enumerate(("port","starboard")):
    center=prop_hub_centers[side_idx]
    rx=center.x+0.034; ry=center.y; rz=WATER_Z+0.004
    rp=add_empty(f"Rudder_{side}_pivot",(rx,ry,rz),COL_DRIVE,display='CIRCLE',size=0.010)
    rp.parent=boat_root; rp.matrix_parent_inverse=Matrix.Identity(4); rp.location=(rx-CX,ry-CY,rz-WATER_Z)
    rp.rotation_mode='XYZ'; rp["sim_baseline_loc"]=(rx,ry,rz); rp["sim_baseline_rot"]=(0.0,0.0,0.0)
    fin=add_box(f"Rudder_{side}_fin",(rx,ry,rz),(0.006,0.020,0.030),MAT_MECH,COL_DRIVE)
    fin.parent=rp; fin.matrix_parent_inverse=Matrix.Identity(4); fin.location=(0.0,0.0,0.0); fin.rotation_euler=(0.0,0.0,0.0)
    fin["role"]="Simulated rudder behind propulsion propeller; paired rudders linked"
    rudder_pivots.append(rp)
# One cross-link and one servo placeholder, placed on the stern frame and parented with local coordinates.
link_x=max(c.x for c in prop_hub_centers)+0.034
link_z=WATER_Z+0.019
link_ob=add_cylinder("Rudder_linkage_crossbar",(link_x,CY,link_z),0.0018,abs(prop_hub_centers[1].y-prop_hub_centers[0].y),MAT_METAL,COL_DRIVE,rotation=(math.pi/2,0,0),vertices=16)
link_ob.parent=boat_root; link_ob.matrix_parent_inverse=Matrix.Identity(4); link_ob.location=(link_x-CX,0.0,link_z-WATER_Z); link_ob.rotation_euler=(math.pi/2,0,0)
servo=add_box("Steering_servo_placeholder",(link_x-0.022,CY,WATER_Z+0.026),(0.018,0.014,0.014),MAT_MECH,COL_DRIVE)
servo.parent=boat_root; servo.matrix_parent_inverse=Matrix.Identity(4); servo.location=(link_x-0.022-CX,0.0,0.026); servo.rotation_euler=(0.0,0.0,0.0)
servo["role"]="Single steering servo placeholder; replace dimensions with selected servo"
arm_start=(link_x-0.013,CY,WATER_Z+0.026)
arm_end=(link_x,CY,WATER_Z+0.019)
arm_delta=Vector(arm_end)-Vector(arm_start)
arm=add_cylinder("Steering_servo_arm_link",(Vector(arm_start)+Vector(arm_end))/2,0.0014,arm_delta.length,MAT_METAL,COL_DRIVE,vertices=12)
arm.rotation_mode='XYZ'; arm.rotation_euler=Vector((0,0,1)).rotation_difference(arm_delta.normalized()).to_euler()
arm.parent=boat_root; arm.matrix_parent_inverse=Matrix.Identity(4); arm.location=((arm_start[0]+arm_end[0])/2-CX,0.0,(arm_start[2]+arm_end[2])/2-WATER_Z)



# ---------------- ACTUAL CAD COLLECTION MECHANISM ----------------
# The conveyor loop/rollers/supports or water-wheel rim/spokes/fins/motor are imported as named V12 CAD meshes.
# No second giant belt or duplicate collector motor/wheel is created here.
mechanism_root=None; roller_roots=[]; conveyor_cleats=[]; wheel_root=None
if VARIANT.lower()=="conveyor":
    collector_x_world=0.034
    collector_z_world=0.060
    intake_half_width=0.028
    front=bpy.data.objects.get("Conveyor_front_roller")
    rear=bpy.data.objects.get("Conveyor_rear_roller")
    belt=bpy.data.objects.get("Conveyor_belt_loop")
    if not all([front,rear,belt]):
        raise RuntimeError("Missing the named V12 conveyor loop or rollers. Ensure the full trash_skimmer_V12_parts/conveyor folder is present.")
    front_center=cad_mesh_center(front); rear_center=cad_mesh_center(rear)
    for idx,(roller,center) in enumerate(((front,front_center),(rear,rear_center)),1):
        rp=make_local_pivot(f"Conveyor_roller_{idx}_SPIN_PIVOT",center,COL_PICKUP,display='CIRCLE',size=0.008)
        reparent_named_mesh_to_pivot(roller,rp,center); link_to(roller,COL_PICKUP); roller_roots.append(rp)
    for name in ("Conveyor_belt_loop","Conveyor_drive_shaft","Conveyor_drive_motor"):
        ob=bpy.data.objects.get(name)
        if ob: link_to(ob,COL_PICKUP)
    for ob in named_parts:
        if ob.name.startswith("Conveyor_"): link_to(ob,COL_PICKUP)
    # Low-profile cleats are animation aids on top of the actual CAD loop; they do not replace the belt.
    # 8 narrow cleats are much smaller than the old oversized conveyor and travel around its closed loop.
    conveyor_cleats=[]
    for ci in range(8):
        cleat=add_box(f"Conveyor_moving_cleat_{ci+1:02d}",(0.0,0.0,0.0),(0.0024,0.050,0.0014),MAT_MECH,COL_PICKUP)
        cleat.parent=boat_root; cleat.matrix_parent_inverse=Matrix.Identity(4)
        cleat.location=(front_center.x-CX,0.0,front_center.z-WATER_Z)
        cleat["role"]="Small moving belt cleat animation proxy on the actual V12 closed-loop conveyor"
        conveyor_cleats.append(cleat)
else:
    collector_x_world=0.014
    collector_z_world=WATER_Z
    intake_half_width=0.040
    hub=bpy.data.objects.get("Waterwheel_hub")
    if not hub:
        raise RuntimeError("Missing Waterwheel_hub in the named V12 moving-part assets.")
    center=cad_mesh_center(hub)
    wheel_root=make_local_pivot("Waterwheel_SPIN_PIVOT",center,COL_PICKUP,display='CIRCLE',size=0.04)
    wheel_parts=[ob for ob in named_parts if ob.name.startswith("Waterwheel_") and any(k in ob.name for k in ("hub","shaft","spoke_","outer_rim","fin_"))]
    for ob in wheel_parts:
        reparent_named_mesh_to_pivot(ob,wheel_root,center); link_to(ob,COL_PICKUP)
    for name in ("Waterwheel_motor_placeholder","Waterwheel_shaft_support_-1","Waterwheel_shaft_support_1","Waterwheel_bearing_collar_-1","Waterwheel_bearing_collar_1"):
        ob=bpy.data.objects.get(name)
        if ob: link_to(ob,COL_PICKUP)
    mechanism_root=wheel_root
COLLECTOR_LOCAL_X=collector_x_world-CX
COLLECTOR_LOCAL_Z=collector_z_world-WATER_Z
# The CAD basket remains part of the static body; its known approximate CAD centre is used only as a transfer target.
BASKET_LOCAL_X=0.1785-CX
BASKET_LOCAL_Y=-0.018-CY
BASKET_LOCAL_Z=0.121-WATER_Z



# ---------------- THREE IR SENSOR PODS + RAY BEAMS ----------------
beam_objects=[]; sensor_objects=[]
# Bow of this design is at the small-X cone tips. Sensor pods sit just aft of those tips.
IR_WORLD_X=0.018
IR_LOCAL_X=IR_WORLD_X-CX
IR_SENSOR_LOCAL=[(IR_LOCAL_X,-0.045,0.028,0.0),(IR_LOCAL_X,0.045,0.028,math.radians(27)),(IR_LOCAL_X,0.0,0.028,math.radians(-27))]
for si,(lx,ly,lz,angle) in enumerate(IR_SENSOR_LOCAL):
    # Cylindrical pods are simulation sensors; the legacy V4 sensor blocks were removed from the V12 CAD.
    sx=0.018-CX; sy=ly; sz=0.028
    pod=add_cylinder(["IR_front_center_pod","IR_port_angle_pod","IR_starboard_angle_pod"][si],
                     (CX+lx,CY+ly,WATER_Z+lz),0.006,0.012,MAT_METAL,COL_SENSORS,rotation=(0,math.pi/2,0),vertices=24)
    pod.parent=boat_root; pod.matrix_parent_inverse=Matrix.Identity(4); pod.location=(lx,ly,lz); pod.rotation_euler=(0.0,math.pi/2,0.0)
    pod["role"]="One of three simulation IR sensor proxies; long-range ray is used for wall-distance telemetry"
    pod["max_range_m"]=IR_MAX_RANGE_M; pod["turn_trigger_m"]=IR_TURN_TRIGGER_M
    sensor_objects.append(pod)
    direction=Vector((-math.cos(angle),-math.sin(angle),0.0))
    beam=add_cylinder(f"IR_{si+1}_range_beam_visual",(CX+lx,CY+ly,WATER_Z+lz),0.0012,IR_MAX_RANGE_M,MAT_IR,COL_SENSORS,vertices=12)
    beam.parent=boat_root; beam.matrix_parent_inverse=Matrix.Identity(4)
    beam.location=(lx+direction.x*IR_MAX_RANGE_M/2,ly+direction.y*IR_MAX_RANGE_M/2,lz)
    beam.rotation_mode='QUATERNION'; beam.rotation_quaternion=Vector((0,0,1)).rotation_difference(direction.normalized())
    beam_objects.append(beam)



# ---------------- SMALL FLOATING LITTER + CONTACT-GATED LIMITED PICKUP ----------------
random.seed(211)
trash_objs=[]; trash_specs=[]
# Place small lightweight pieces across the lane coverage area and near the waterplane.
# The intake position comes from the chosen CAD collector, not a wide arbitrary capture envelope.
TRASH_COUNT=min(MAX_TRASH_ITEMS, max(8, len(lane_values)*4))
intake_x=COLLECTOR_LOCAL_X; intake_z=COLLECTOR_LOCAL_Z
kind_masses=[0.00065,0.00080,0.00045,0.00145]
kind_half_x=[0.012,0.007,0.004,0.012]
kind_half_y=[0.009,0.006,0.004,0.006]
# Spread litter along the whole pool and across the full sweep width, aligned to the intake lanes.
# This avoids the old bug where all 20 pieces were placed in only the first five lanes.
TRASH_COUNT=min(MAX_TRASH_ITEMS, max(8, len(lane_values)*2))
for idx in range(TRASH_COUNT):
    lane_i=round(idx*(len(lane_values)-1)/max(1,TRASH_COUNT-1))
    lane_y=lane_values[lane_i]
    slot_in_four=idx%4
    x_start=X_LEFT+intake_x+0.045
    xoff=x_start+slot_in_four*(max(0.01,(X_RIGHT-X_LEFT-0.09))/3.0)
    xw=CX+xoff; yw=CY+lane_y+random.uniform(-0.002,0.002)
    kind=idx%4
    if kind==0:
        thickness=0.0025; zw=WATER_Z+thickness/2
        ob=add_irregular_litter(f"TRASH_{idx+1:02d}_wrapper",(xw,yw,zw),(0.024,0.018),thickness,MAT_TRASH[kind],COL_TRASH,seed=idx+211,sides=7)
        ob.rotation_euler[2]=random.uniform(-0.5,0.5)
    elif kind==1:
        thickness=0.003; zw=WATER_Z+thickness/2
        ob=add_irregular_litter(f"TRASH_{idx+1:02d}_small_fragment",(xw,yw,zw),(0.014,0.012),thickness,MAT_TRASH[kind],COL_TRASH,seed=idx+407,sides=5)
        ob.rotation_euler[2]=random.uniform(-0.7,0.7)
    elif kind==2:
        thickness=0.003; zw=WATER_Z+thickness/2
        ob=add_cylinder(f"TRASH_{idx+1:02d}_small_cap",(xw,yw,zw),0.004,thickness,MAT_TRASH[kind],COL_TRASH,vertices=16)
    else:
        radius=0.004; zw=WATER_Z+radius
        ob=add_cylinder(f"TRASH_{idx+1:02d}_mini_bottle",(xw,yw,zw),radius,0.022,MAT_TRASH[kind],COL_TRASH,rotation=(0,math.pi/2,0),vertices=20)
    ob["role"]="Small floating litter proxy, with base tangent to visual waterline; not a rigid-body fluid object"
    mass=kind_masses[kind]
    ob["assumed_mass_kg"]=mass; ob["capture_state"]="FLOATING"
    trash_objs.append(ob)
    trash_specs.append({"object":ob,"x":xw,"y":yw,"z":zw,"mass":mass,"kind":kind,"half_x":kind_half_x[kind],"half_y":kind_half_y[kind],"capture_frame":None,"slot":None})

loaded=[]; loaded_mass=0.0
transfer_frames=max(10,int(TRASH_TRANSFER_SECONDS*FPS))
BASKET_LOCAL_X=0.1785-CX
BASKET_LOCAL_Y=-0.018-CY
BASKET_LOCAL_Z=0.121-WATER_Z
if VARIANT.lower()=="conveyor":
    transfer_path=[(intake_x,0.004,intake_z+0.002),(intake_x+0.030,0.006,0.030),(intake_x+0.065,0.004,0.050),(0.115-CX,0.0,0.065),(BASKET_LOCAL_X,BASKET_LOCAL_Y,BASKET_LOCAL_Z)]
else:
    transfer_path=[(intake_x,0.006,intake_z+0.003),(intake_x+0.018,0.012,0.024),(intake_x+0.045,0.008,0.042),(intake_x+0.085,0.004,0.058),(BASKET_LOCAL_X,BASKET_LOCAL_Y,BASKET_LOCAL_Z)]

def world_from_local(rootx,rooty,theta,local_xyz):
    rx,ry=rotate2(local_xyz[0],local_xyz[1],theta)
    return (rootx+rx,rooty+ry,WATER_Z+local_xyz[2])

def interp_path(points,t):
    t=max(0.0,min(1.0,t)); scaled=t*(len(points)-1); si=min(int(scaled),len(points)-2); f=scaled-si
    a=points[si]; b=points[si+1]
    return tuple(a[k]*(1-f)+b[k]*f for k in range(3))

# Narrow inlet contact gate: correct fore/aft coordinate, actual collector width, and waterline proximity.
for i,p in enumerate(poses):
    fr=i+1; wx,wy=root_world_xy(p["x"],p["y"]); th=yaws[i]
    for spec in trash_specs:
        if spec["capture_frame"] is not None: continue
        dx=spec["x"]-wx; dy=spec["y"]-wy
        lx=math.cos(th)*dx+math.sin(th)*dy
        ly=-math.sin(th)*dx+math.cos(th)*dy
        vertical_gap=abs(spec["z"]-WATER_Z)
        x_tol=0.012+spec["half_x"]
        y_tol=intake_half_width+spec["half_y"]
        if abs(lx-intake_x)<=x_tol and abs(ly)<=y_tol and vertical_gap<=0.008:
            if len(loaded)<MAX_TRASH_ITEMS and loaded_mass+spec["mass"]<=MAX_TRASH_MASS_KG+1e-9:
                spec["capture_frame"]=fr; spec["slot"]=len(loaded)
                loaded.append(spec); loaded_mass+=spec["mass"]
                spec["object"]["capture_state"]="CAPTURED_CONTACT_GATE"
                spec["object"]["capture_frame"]=fr
            else:
                spec["object"]["capture_state"]="LEFT_FLOATING_CAPACITY_FULL"

# Animate loose litter bobbing just above the waterplane; captured litter follows the intake-to-basket path.
for i,p in enumerate(poses):
    fr=i+1; wx,wy=root_world_xy(p["x"],p["y"]); th=yaws[i]
    for spec in trash_specs:
        ob=spec["object"]; cf=spec["capture_frame"]
        if cf is None:
            bob=0.00035*math.sin(2*math.pi*(i/FPS)/3.5+spec["kind"])
            ob.location=(spec["x"],spec["y"],spec["z"]+bob)
            ob.keyframe_insert(data_path='location',frame=fr)
        else:
            elapsed=fr-cf; slot=spec["slot"]
            slot_x=BASKET_LOCAL_X+((slot%4)-1.5)*0.010
            slot_y=BASKET_LOCAL_Y+(((slot//4)%2)-0.5)*0.020
            slot_z=BASKET_LOCAL_Z+0.008+(slot//8)*0.005
            end_local=(slot_x,slot_y,slot_z)
            if elapsed<transfer_frames:
                pr=elapsed/transfer_frames; local=interp_path(transfer_path,pr)
                if pr>0.78:
                    f=(pr-0.78)/0.22
                    local=tuple(local[k]*(1-f)+end_local[k]*f for k in range(3))
            else: local=end_local
            ob.location=world_from_local(wx,wy,th,local)
            ob.keyframe_insert(data_path='location',frame=fr)
            if elapsed>=transfer_frames: ob["capture_state"]="IN_BASKET"
            elif fr>cf: ob["capture_state"]="IN_TRANSFER"



# ---------------- BAKE ACTUAL PART ROTATION AND MECHANISM MOTION ----------------
# The root follows a precomputed wall-safe lawn-mower path. Differential RPM is derived from each segment's
# speed/yaw rate and exported to telemetry. This is kinematic animation, not thrust-validated hydrodynamics.
# Propeller pivots rotate on the true CAD shaft axis (X); both the CAD shaft and blades share the same pivot.
for i,p in enumerate(poses):
    fr=i+1; row=telemetry[i]; t=i/FPS
    for side_idx,pivot in enumerate(prop_pivots):
        rpm=row["left_prop_rpm_model"] if side_idx==0 else row["right_prop_rpm_model"]
        pivot.rotation_mode='XYZ'; pivot.rotation_euler[0]=2*math.pi*(rpm*VISUAL_PROP_SPIN_SCALE/60.0)*t
        pivot.keyframe_insert(data_path='rotation_euler',frame=fr)
    diff=(row["right_motor_rpm_command"]-row["left_motor_rpm_command"])/max(MAX_MOTOR_RPM,1.0)
    rudder_angle=max(-math.radians(28),min(math.radians(28),diff*math.radians(28)))
    for rp in rudder_pivots:
        rp.rotation_mode='XYZ'; rp.rotation_euler[2]=rudder_angle; rp.keyframe_insert(data_path='rotation_euler',frame=fr)
    # IR beams are only visual range cues; truncate them at the nearest rectangular pool wall.
    for si,beam in enumerate(beam_objects):
        lx,ly,lz,ang=IR_SENSOR_LOCAL[si]
        theta=yaws[i]; wx=CX+poses[i]["x"]; wy=CY+poses[i]["y"]
        sx,sy=rotate2(lx,ly,theta); ox=wx+sx; oy=wy+sy
        rayang=theta+ang; dxr=-math.cos(rayang); dyr=-math.sin(rayang)
        dist=ray_rect_distance(ox,oy,dxr,dyr,IR_MAX_RANGE_M)
        localdir=Vector((-math.cos(ang),-math.sin(ang),0.0))
        beam.location=(lx+localdir.x*dist/2,ly+localdir.y*dist/2,lz)
        beam.rotation_mode='QUATERNION'; beam.rotation_quaternion=Vector((0,0,1)).rotation_difference(localdir.normalized())
        beam.scale=(1.0,1.0,max(0.001,dist/IR_MAX_RANGE_M))
        beam.keyframe_insert(data_path='location',frame=fr); beam.keyframe_insert(data_path='rotation_quaternion',frame=fr); beam.keyframe_insert(data_path='scale',frame=fr)
    if VARIANT.lower()=="waterwheel" and wheel_root:
        wheel_root.rotation_mode='XYZ'; wheel_root.rotation_euler[1]=-2*math.pi*54.0/60.0*t
        wheel_root.keyframe_insert(data_path='rotation_euler',frame=fr)
    elif VARIANT.lower()=="conveyor":
        for idx,rp in enumerate(roller_roots):
            rp.rotation_mode='XYZ'; rp.rotation_euler[1]=2*math.pi*68.0/60.0*t
            rp.keyframe_insert(data_path='rotation_euler',frame=fr)
        # Cleats move around the same closed loop geometry as the CAD belt and rollers.
        front_center=cad_mesh_center(bpy.data.objects["Conveyor_front_roller"])
        rear_center=cad_mesh_center(bpy.data.objects["Conveyor_rear_roller"])
        ax,az=front_center.x,front_center.z
        bx,bz=rear_center.x,rear_center.z
        # STL assets were scaled from millimetres to metres during import.
        L=math.hypot(bx-ax,bz-az); ux=(bx-ax)/L; uz=(bz-az)/L; nx=-uz; nz=ux; R=0.00555
        phi=math.atan2(ux,-uz); total=2*L+2*math.pi*R; speed=0.040
        for ci,cleat in enumerate(conveyor_cleats):
            d=(ci*total/len(conveyor_cleats)+speed*t)%total
            if d<L:
                x=ax+nx*R+ux*d; z=az+nz*R+uz*d; tx,tz=ux,uz
            elif d<L+math.pi*R:
                q=d-L; a=phi-q/R; x=bx+R*math.cos(a); z=bz+R*math.sin(a); tx,tz=math.sin(a),-math.cos(a)
            elif d<2*L+math.pi*R:
                q=d-(L+math.pi*R); x=bx-nx*R-ux*q; z=bz-nz*R-uz*q; tx,tz=-ux,-uz
            else:
                q=d-(2*L+math.pi*R); a=phi-math.pi-q/R; x=ax+R*math.cos(a); z=az+R*math.sin(a); tx,tz=math.sin(a),-math.cos(a)
            cleat.location=(x-CX,0.0,z-WATER_Z)
            cleat.rotation_euler=(0.0,-math.atan2(tz,tx),0.0)
            cleat.keyframe_insert(data_path='location',frame=fr); cleat.keyframe_insert(data_path='rotation_euler',frame=fr)



# ---------------- NO VISIBLE ROUTE LINE ----------------
# Route exists only in the baked boat animation and telemetry; no path curve is drawn in the pool.

# Pool labels, camera and lights.
def add_text(name,body,location,size,mat,col):
    cu=bpy.data.curves.new(name+'_font','FONT'); cu.body=body; cu.size=size; cu.extrude=0.0002
    ob=bpy.data.objects.new(name,cu); col.objects.link(ob); ob.location=location
    if mat: cu.materials.append(mat)
    return ob
# Simple HAPI wordmark only, placed tangent to the outboard sides of both pontoons like printed paint.
def add_hapi_pontoon_marks():
    candidates=[]
    for ob in static_parts:
        try:
            d=ob.dimensions.copy()
            c=sum((ob.matrix_world @ Vector(v) for v in ob.bound_box),Vector((0,0,0)))/8.0
            if d.x>0.40 and 0.065<d.y<0.085 and 0.065<d.z<0.085 and abs(c.y)>0.065 and c.z<0.12:
                candidates.append((d.x*d.y*d.z,c.y,c.x,c.z,d.y))
        except Exception: pass
    for sign in (-1,1):
        opts=[a for a in candidates if (a[1]<0 if sign<0 else a[1]>0)]
        if not opts: continue
        _,cy0,cx0,cz0,dy0=max(opts,key=lambda a:a[0])
        # Put the text just outside the shell side; 0.7 mm stand-off avoids z-fighting.
        side_y=cy0+sign*(dy0/2.0+0.0007)
        cu=bpy.data.curves.new('HAPI_wordmark_curve','FONT'); cu.body='HAPI'; cu.size=0.030; cu.align_x='CENTER'; cu.align_y='CENTER'; cu.extrude=0.000015; cu.bevel_depth=0.000008
        ob=bpy.data.objects.new('HAPI | painted pontoon name '+('port' if sign<0 else 'starboard'),cu); COL_CAD_MOVING.objects.link(ob)
        cu.materials.append(MAT_LOGO)
        ob.parent=boat_root; ob.matrix_parent_inverse=Matrix.Identity(4)
        ob.location=(cx0-CX,side_y-CY,cz0-WATER_Z)
        ob.rotation_euler=(math.pi/2,0.0,0.0 if sign<0 else math.pi)
        ob['role']='HAPI name-only side marking; visual decal approximation, not a physical raised logo'
add_hapi_pontoon_marks()

# Local prop wash: small low-poly droplets remain near the actual stern propeller locations.
def add_ico_drop(name, location, radius, mat, col):
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1,radius=radius,location=location)
    ob=bpy.context.object; ob.name=name; ob.data.materials.append(mat); link_to(ob,col)
    for poly in ob.data.polygons: poly.use_smooth=True
    return ob
random.seed(1307)
propwash_drops=[]
for side_idx,center in enumerate(prop_hub_centers):
    side_name='port' if side_idx==0 else 'starboard'
    for di in range(8):
        dx=random.uniform(-0.018,0.026); dy=random.uniform(-0.018,0.018); dz=random.uniform(0.003,0.024)
        world=(center.x+dx,center.y+dy,WATER_Z+dz)
        drop=add_ico_drop(f'PROP_WASH_{side_name}_{di+1:02d}',world,random.uniform(0.0025,0.0042),MAT_FOAM,COL_DRIVE)
        drop.parent=boat_root; drop.matrix_parent_inverse=Matrix.Identity(4)
        drop.location=(world[0]-CX,world[1]-CY,world[2]-WATER_Z)
        drop['role']='Lightweight animated prop-wash splash visual; not fluid particles'
        propwash_drops.append((drop,side_idx,di,drop.location.copy()))
# Animate splashes without a particle simulation, for low render cost on RTX 2070-class GPUs.
for fr in range(1,len(poses)+1,6):
    t=(fr-1)/FPS
    for drop,side_idx,di,base_loc in propwash_drops:
        phase=di*1.7+side_idx*0.9
        drop.location=(base_loc.x+0.0025*math.sin(t*5.1+phase),base_loc.y+0.002*math.cos(t*4.3+phase),base_loc.z+0.012*abs(math.sin(t*6.5+phase)))
        k=0.35+0.65*abs(math.sin(t*5.3+phase))
        drop.scale=(k,k,k)
        drop.keyframe_insert(data_path='location',frame=fr); drop.keyframe_insert(data_path='scale',frame=fr)

# Tiny, local wake ripples only: short-lived rings behind the stern, never a drawn route line.
# Sampling sparsely keeps the scene light and leaves only a short visible trail behind the moving boat.
for idx in range(0,len(poses),max(1,int(FPS*1.25))):
    p=poses[idx]; theta=yaws[idx]; wx=CX+p['x']; wy=CY+p['y']; frame0=idx+1
    for ring_i,back in enumerate((HALF_LENGTH+0.025,HALF_LENGTH+0.085)):
        offx,offy=rotate2(back,(0.012 if ring_i else -0.012),theta)
        bpy.ops.mesh.primitive_torus_add(major_segments=24,minor_segments=5,major_radius=0.026,minor_radius=0.0012,location=(wx+offx,wy+offy,WATER_Z+0.0007))
        ring=bpy.context.object; ring.name=f'LOCAL_WAKE_{idx:05d}_{ring_i}'; link_to(ring,COL_POOL); ring.data.materials.append(MAT_WAKE)
        ring.rotation_euler[2]=theta; ring.scale=(0.65,0.38,0.22)
        ring['role']='Short-lived local wake ripple; not a fluid solution and not a route line'
        ring.hide_render=True; ring.keyframe_insert(data_path='hide_render',frame=1)
        ring.hide_render=False; ring.keyframe_insert(data_path='hide_render',frame=frame0)
        ring.scale=(0.22,0.15,0.22); ring.keyframe_insert(data_path='scale',frame=frame0)
        ring.scale=(0.95,0.55,0.22); ring.keyframe_insert(data_path='scale',frame=frame0+12)
        ring.scale=(1.45,0.78,0.22); ring.keyframe_insert(data_path='scale',frame=frame0+36)
        ring.hide_render=True; ring.keyframe_insert(data_path='hide_render',frame=frame0+42)

# 3D labels at the pool lip; there is deliberately no visible lawn-mower route curve.
add_text("POOL_LABEL","HAPI | TRASH-SKIMMER CONTROLLED POOL TEST",(CX-POOL_HALF_X+0.04,CY-POOL_HALF_Y-0.12,0.465),0.040,MAT_FRAME,COL_STAGE)
add_text("ASSUMPTION_LABEL","DARK-NAVY PONTOONS / WHITE HULL  |  EEVEE BALANCED PRESET",(CX-POOL_HALF_X+0.04,CY+POOL_HALF_Y+0.06,0.465),0.022,MAT_FRAME,COL_STAGE)

# Overview camera: full square pool and complete route context.
bpy.ops.object.camera_add(location=(CX+2.9,CY-3.6,3.0))
cam_overview=bpy.context.object; cam_overview.name='Camera | OVERVIEW full square pool'; link_to(cam_overview,COL_STAGE)
cam_overview.rotation_euler=(Vector((CX,CY,0.07))-cam_overview.location).to_track_quat('-Z','Y').to_euler()
cam_overview.data.type='ORTHO'; cam_overview.data.ortho_scale=6.40; cam_overview.data.lens=45
# Follow camera: a low, elevated three-quarter angle that follows the animated boat root.
bpy.ops.object.camera_add(location=(CX+0.60,CY-0.82,WATER_Z+0.54))
cam_follow=bpy.context.object; cam_follow.name='Camera | FOLLOW boat hero angle'; link_to(cam_follow,COL_STAGE)
cam_follow.parent=boat_root; cam_follow.matrix_parent_inverse=Matrix.Identity(4)
cam_follow.location=(0.60,-0.82,0.54)
cam_follow.rotation_euler=(Vector((0.0,0.0,0.105))-Vector(cam_follow.location)).to_track_quat('-Z','Y').to_euler()
cam_follow.data.type='PERSP'; cam_follow.data.lens=42; cam_follow.data.clip_start=0.02; cam_follow.data.clip_end=100
scene.camera=cam_follow if CAMERA_MODE.upper()=="FOLLOW" else cam_overview
# Lightweight in-camera engineering HUD, parented to the follow camera so it remains readable during a chase render.
# The information is duplicated in CSV telemetry for analysis; all values are explicitly assumption-based.
def add_camera_hud_text(body, local_location, size, mat):
    cu=bpy.data.curves.new('HAPI_HUD_text_curve','FONT'); cu.body=body; cu.size=size; cu.align_x='LEFT'; cu.extrude=0.0
    ob=bpy.data.objects.new('HUD | '+body.split('\n')[0],cu); COL_STAGE.objects.link(ob); cu.materials.append(mat)
    ob.parent=cam_follow; ob.matrix_parent_inverse=Matrix.Identity(4); ob.location=local_location; ob.rotation_euler=(0,0,0)
    ob['role']='Camera-space engineering overlay; assumption values are not measurements'
    return ob
# Overlay at camera-local depth in front of the hull; keep it compact for readability.
hud_panel=add_box('HUD | engineering assumptions panel',(0,0,0),(0.245,0.092,0.003),MAT_POOL_INNER,COL_STAGE)
hud_panel.parent=cam_follow; hud_panel.matrix_parent_inverse=Matrix.Identity(4); hud_panel.location=(-0.125,0.17,-0.62); hud_panel.rotation_euler=(0,0,0)
hud_text=add_camera_hud_text(
    f'HAPI | V13\nDRY MASS* {BOAT_MASS_KG_ASSUMED:.2f} kg\nRATED CURRENT BUDGET* {TOTAL_RATED_CURRENT_A_ASSUMED:.1f} A\nCAPACITY {MAX_TRASH_ITEMS} items / {MAX_TRASH_MASS_KG*1000:.0f} g',
    (-0.235,0.205,-0.615),0.0105,MAT_LOGO)
hud_text['note']='Static design assumptions. Actual payload mass is written to telemetry CSV; current estimate excludes measured startup/stall current.' 
for name,loc,power,size in [('Key',(CX-0.8,CY-1.2,2.7),1350,2.2),('Fill',(CX+1.4,CY+0.9,2.0),900,1.7),('Rim',(CX-1.4,CY+0.8,1.8),800,1.4)]:
    bpy.ops.object.light_add(type='AREA',location=loc); light=bpy.context.object; light.name='Light | '+name; light.data.energy=power; light.data.shape='DISK'; light.data.size=size
    light.rotation_euler=(Vector((CX,CY,0.07))-light.location).to_track_quat('-Z','Y').to_euler(); link_to(light,COL_STAGE)

# ---------------- ENGINEERING TELEMETRY / SUMMARY ----------------
# Match trash count/mass to the actual proximity-capture state machine.
for row in telemetry:
    fr=row["frame"]
    collected=[s for s in loaded if s["capture_frame"]<=fr]
    row["collected_items"] = len(collected)
    row["collected_mass_kg"] = sum(s["mass"] for s in collected)
    row["capacity_items_limit"] = MAX_TRASH_ITEMS
    row["capacity_mass_limit_kg"] = MAX_TRASH_MASS_KG
    row["capacity_full"] = int(len(collected)>=MAX_TRASH_ITEMS or sum(s["mass"] for s in collected)>=MAX_TRASH_MASS_KG)
    row["dry_mass_assumed_kg"] = BOAT_MASS_KG_ASSUMED
    row["total_mass_assumed_kg"] = BOAT_MASS_KG_ASSUMED + row["collected_mass_kg"]
    row["required_displacement_L_assumed"] = (row["total_mass_assumed_kg"] / WATER_DENSITY_KG_M3) * 1000.0
    # An intentionally simple rated-current proxy, not a DC motor torque/stall-current model.
    throttle_l=abs(row["left_motor_rpm_command"])/max(MAX_MOTOR_RPM,1.0)
    throttle_r=abs(row["right_motor_rpm_command"])/max(MAX_MOTOR_RPM,1.0)
    row["estimated_current_proxy_A"] = MOTOR_NOMINAL_CURRENT_A*(throttle_l+throttle_r)+ACCESSORY_CURRENT_A_ASSUMED
    row["current_model_note"] = "linearized rated-power proxy; excludes measured startup/stall and actual driver losses"
    row["pool_x_extent_m"] = POOL_LENGTH_M
    row["pool_y_extent_m"] = POOL_WIDTH_M

with open(OUTPUT_TELEMETRY,'w',newline='',encoding='utf-8') as f:
    fields=list(telemetry[0].keys())
    w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(telemetry)

captured_count=len(loaded); captured_mass=sum(s["mass"] for s in loaded)
summary=[
    ("collector_variant",VARIANT,"selected animation variant"),
    ("source_stl",SOURCE_STL,"input V12 static-body STL; named moving parts are imported from trash_skimmer_V12_parts"),
    ("boat_length_m",BOAT_LENGTH,"from imported STL envelope"),
    ("boat_width_m",BOAT_WIDTH,"from imported STL envelope"),
    ("boat_height_m",BOAT_HEIGHT,"from imported STL envelope"),
    ("pool_inner_length_m",POOL_LENGTH_M,"square controlled environment; edit at top of script"),
    ("pool_inner_width_m",POOL_WIDTH_M,"square controlled environment; matches length"),
    ("nominal_current_if_2x80W_12V_motors_A",PROPULSION_MOTOR_COUNT*MOTOR_NOMINAL_CURRENT_A,"rated input current estimate only; no startup/stall or driver losses"),
    ("accessory_current_allowance_A",ACCESSORY_CURRENT_A_ASSUMED,"rough editable allowance, not measured"),
    ("total_nominal_current_budget_A",TOTAL_RATED_CURRENT_A_ASSUMED,"illustrative nominal budget, not battery sizing approval"),
    ("minimum_hull_wall_clearance_m",min_clearance,"computed envelope clearance for prescribed trajectory"),
    ("ir_proxy_range_m",IR_MAX_RANGE_M,"editable simulated sensor range"),
    ("ir_turn_trigger_m",IR_TURN_TRIGGER_M,"turn trigger; route is wall-safe, not a live obstacle physics solver"),
    ("max_motor_rpm_assumption",MAX_MOTOR_RPM,"provisional motor RPM; verify selected motor under load"),
    ("motor_to_propeller_rpm_ratio",PROP_RPM_RATIO,"provisional gearing/coupling ratio; replace with real value"),
    ("track_width_m",TRACK_WIDTH_M,"CAD pontoon centreline spacing approx. 192 mm"),
    ("maximum_propeller_rpm_model",MAX_PROP_RPM,"derived assumption, not measured"),
    ("cruise_speed_assumption_m_s",CRUISE_SPEED_M_S,"editable trajectory speed, not measured"),
    ("max_yaw_rate_assumption_rad_s",MAX_YAW_RATE_RAD_S,"simplified differential RPM/yaw relationship"),
    ("petg_density_assumption_kg_m3",PETG_DENSITY_KG_M3_ASSUMED,"PETG visual choice; printed part/infill mass not measured"),
    ("boat_total_mass_assumption_kg",BOAT_MASS_KG_ASSUMED,"whole boat mass placeholder; replace with assembled boat scale measurement"),
    ("nominal_current_budget_A_assumed",TOTAL_RATED_CURRENT_A_ASSUMED,"2 x 80 W / 12 V propulsion estimate + 1.8 A accessory allowance; not measured, excludes startup/stall"),
    ("required_displacement_L_at_dry_mass_assumption",BOAT_MASS_KG_ASSUMED/WATER_DENSITY_KG_M3*1000.0,"Archimedes relation; static estimate only, not proof of stability"),
    ("water_density_kg_m3",WATER_DENSITY_KG_M3,"fresh-water-like assumption"),
    ("trash_items_spawned",len(trash_specs),"small floating litter proxies"),
    ("trash_items_collected",captured_count,"from intake proximity checks and capacity state"),
    ("trash_mass_collected_kg",captured_mass,"piece masses are placeholders"),
    ("trash_item_capacity",MAX_TRASH_ITEMS,"hard collection limit in controller"),
    ("trash_mass_capacity_kg",MAX_TRASH_MASS_KG,"hard collection limit in controller; not buoyancy-certified"),
    ("simulation_frames",len(poses),"baked deterministic animation"),
    ("simulation_duration_s",(len(poses)-1)/FPS,"at the configured frame rate"),
    ("fluid_dynamics_solver",0,"no CFD/real buoyancy solver included"),
    ("wall_collision_handling",1,"trajectory constrained by full hull envelope; pool walls are not penetrated on baked route")
]
with open(OUTPUT_SUMMARY,'w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(["parameter","value","notes"]); w.writerows(summary)

# Separate component assumptions register for editing once the team measures the actual hardware.
component_rows = [
    ["Printed hull/frame assembly (whole boat placeholder)",1,BOAT_MASS_KG_ASSUMED,0.0,"PLACEHOLDER","Whole assembled dry mass placeholder; do not add component masses to this again unless re-basing."],
    ["775 DC propulsion motor, 12 V / 80 W / 13000 RPM",2,"",MOTOR_NOMINAL_CURRENT_A,"ESTIMATED CURRENT ONLY","Mass unknown. 80 W / 12 V = rated input current only IF 80 W is electrical input power; startup/stall current not included."],
    ["JGA25-370 geared motor 12 V / 130 RPM (alternative)",2,0.095,"","PROVISIONAL MASS","Earlier comparison suggested 88-100 g each; 95 g midpoint only. Alternate motor option, not simultaneously counted."],
    ["L298N motor-driver board",1,0.030,"","APPROXIMATE MASS","Approx. 30 g from project notes. Check actual driver current rating against selected motors; not assumed suitable for 775 motors."],
    ["BTS7960 high-current driver (alternative)",1,"","","UNKNOWN","Availability, module rating, and mass have not been verified for the actual purchased board."],
    ["Propeller (selected diameter TBD)",2,"",0.0,"UNKNOWN MASS","Team component sheet lists candidate sizes; exact selected propeller and thrust curve still required."],
    ["Drive shaft / coupler",2,"",0.0,"UNKNOWN MASS","Measure the installed shaft and coupler."],
    ["IR distance sensor",3,0.004,0.020,"ASSUMED MIDPOINT","4 g and 20 mA per sensor are rough placeholders; replace with exact module datasheet."],
    ["ESP32 AI Thinker AiPi-Cam D200",1,"",0.300,"CURRENT PLACEHOLDER","Mass and current not provided in readable component table; 0.3 A is a rough budget allowance only."],
    ["Collector geared motor (conveyor or wheel)",1,0.095,1.000,"PROVISIONAL","95 g, 1 A are placeholders based on geared-motor option; measure actual loaded current."],
    ["Steering servo",1,0.015,0.500,"PROVISIONAL","15 g, 0.5 A budget placeholders; verify selected servo peak current."],
    ["Battery pack",1,"","","UNKNOWN","Battery chemistry, series/parallel arrangement, capacity, protection, mass, and continuous current remain undecided."],
]
with open(OUTPUT_COMPONENT_BUDGET,'w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(["component","quantity","unit_mass_kg_or_blank","unit_current_A_or_blank","status","notes"]); w.writerows(component_rows)
with open(OUTPUT_MASS_CURRENT,'w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(["time_s","collected_items","collected_mass_kg","dry_mass_assumed_kg","total_mass_assumed_kg","required_displacement_L_assumed","estimated_current_proxy_A","current_model_note"])
    for row in telemetry:
        w.writerow([row["time_s"],row["collected_items"],row["collected_mass_kg"],row["dry_mass_assumed_kg"],row["total_mass_assumed_kg"],row["required_displacement_L_assumed"],row["estimated_current_proxy_A"],row["current_model_note"]])

# Scene metadata and opening frame.
scene["project"]="V13 HAPI twin-pontoon trash skimmer | controlled pool simulation"
scene["collector_variant"]=VARIANT
scene["camera_mode"]=CAMERA_MODE
scene["pool_shape"]="square"
scene["pool_dimensions_m"]=(POOL_LENGTH_M,POOL_WIDTH_M)
scene["render_preset"]=f"Eevee {RENDER_PRESET.upper()}: 1280x720, {scene.render.resolution_percentage}%, 24fps; {24 if RENDER_PRESET.upper()=='BALANCED' else 8} samples; intended for RTX 2070-class hardware"
scene["nominal_current_budget_A_assumed"]=TOTAL_RATED_CURRENT_A_ASSUMED
scene["dry_mass_kg_assumed_placeholder"]=BOAT_MASS_KG_ASSUMED
scene["material_choice"]="PETG visual/material assumption; printed infill and assembled weight not measured"
scene["control_model"]="Differential RPM kinematic inverse. Yaw response and motor-to-prop ratio are assumptions, not thrust-calibrated dynamics."
scene["sensor_model"]=f"Three cylindrical IR pods; {IR_MAX_RANGE_M:.2f} m range and {IR_TURN_TRIGGER_M:.2f} m turn trigger; prescribed lawn-mower path kept within hull envelope."
scene["capacity_model"]=f"{MAX_TRASH_ITEMS} items or {MAX_TRASH_MASS_KG:.3f} kg, whichever comes first"
scene["limits"]="Water sheet has lightweight wave modifier and local wake/splash visuals only. No CFD, rigid-body fluid interaction, measured thrust curve, or validated buoyancy. Mass, current, RPM ratio and steering response are editable assumptions."
scene.frame_set(1)
for area in bpy.context.screen.areas if bpy.context.screen else []:
    if area.type=='VIEW_3D':
        area.spaces.active.region_3d.view_location=(CX,CY,0.08); area.spaces.active.region_3d.view_distance=3.8
os.makedirs(os.path.join(SCRIPT_DIR,"renders"),exist_ok=True)
if RENDER_PRESET.upper() == "PREVIEW":
    # Keep all baked animation keys and telemetry, but limit the .blend timeline to a 10-second smoke test.
    scene.frame_end=min(scene.frame_end,FPS*10)
    scene.render.filepath=os.path.join(SCRIPT_DIR,"renders",f"HAPI_V13_{VARIANT}_preview.mp4")
else:
    scene.render.filepath=os.path.join(SCRIPT_DIR,"renders",f"HAPI_V13_{VARIANT}_follow.mp4")
bpy.ops.wm.save_as_mainfile(filepath=OUTPUT_BLEND)
print("V13 pool simulation created:",OUTPUT_BLEND)
print("Telemetry CSV:",OUTPUT_TELEMETRY)
print("Mass/current CSV:",OUTPUT_MASS_CURRENT)
print("Component budget CSV:",OUTPUT_COMPONENT_BUDGET)
print("Summary CSV:",OUTPUT_SUMMARY)
print("Variant:",VARIANT,"| frames:",len(poses),"| duration s:",(len(poses)-1)/FPS)
print("Minimum envelope-to-wall clearance m:",round(min_clearance,4))
print("Trash pickup:",captured_count,"items /",round(captured_mass,4),"kg of placeholder mass")
