HAPI V13 — BLENDER PRESENTATION + KINEMATIC SIMULATION STARTER
================================================================

WHAT THIS PACKAGE DOES
- Imports the existing V12 HAPI boat geometry and its named CAD moving-part meshes.
- Builds a 4.2 m x 4.2 m square test pool (four walls, bottom, and a water surface), with a larger 14-lane sweep under current hull/clearance assumptions.
- Applies a deep navy finish to the pontoons, a white central hull, a dark-blue roof, and matte-black propulsion parts.
- Adds a name-only HAPI wordmark on the outside of the pontoons as a visual paint/decal approximation.
- Generates a longer lawn-mower sweep with 14 lanes under the current geometry/settings, plus differential-RPM commands and wall-clearance telemetry.
- Animates the actual named CAD propeller hubs/blades/shafts, rudders, active collector mechanism, and conveyor cleats.
- Creates small floating litter proxies, a capacity limit, water ripples, local prop-wash droplets and short-lived wake rings.
- Creates FOLLOW and OVERVIEW cameras. FOLLOW is active by default.
- Exports CSV telemetry and a component mass/current assumption register when the scene is built.

IMPORTANT: No Blender runtime was available when this package was assembled. The builder has passed Python syntax compilation and package/archive checks, but it has not been executed in Blender here. This ZIP is a ready-to-run scene-builder + source assets, not a pre-rendered .blend or video.

FILES AND FOLDER LAYOUT
- build_trash_skimmer_simulation_V13.py
- trash_skimmer_V12_conveyor_static_body.stl
- trash_skimmer_V12_waterwheel_static_body.stl
- trash_skimmer_V12_parts/conveyor/*
- trash_skimmer_V12_parts/waterwheel/*
- trash_skimmer_V12_simulation_assumptions.csv (reference register from the prior starter)
- HAPI_V13_scene_assumptions.csv

SETUP
1. Extract the ENTIRE ZIP to a folder. Keep the script, both static-body STL files, and the full trash_skimmer_V12_parts folder together.
2. Open Blender and switch to the Scripting workspace.
3. Open build_trash_skimmer_simulation_V13.py from the extracted folder.
4. At the top, set VARIANT = "conveyor" or VARIANT = "waterwheel".
5. Set CAMERA_MODE = "FOLLOW" (default) for the close three-quarter chase camera, or "OVERVIEW" for a full-pool view.
6. Click Run Script. The scene builder is designed to save HAPI_trash_skimmer_V13_<variant>_pool_simulation.blend and write the CSV outputs beside the script.

RENDER TO VIDEO
- The scene is configured for FFmpeg MPEG-4 / H.264 output into a renders subfolder.
- Open the saved .blend file and use Render > Render Animation (Ctrl+F12 on most default keymaps).
- Default balanced preset: Eevee, 1280 x 720 output at 80%, 24 fps, 24 samples. This is intended as a modest starting point for an RTX 2070-class GPU, not a guaranteed render-time estimate.
- The longer 4.2 m pool sweep is around 4 minutes 20 seconds of animation under current speed/turn assumptions. To build a 10-second smoke-test scene, change RENDER_PRESET = "BALANCED" to RENDER_PRESET = "PREVIEW" and run the builder again. PREVIEW uses 45% resolution, 8 samples, and a 10-second timeline. For a full final, restore RENDER_PRESET = "BALANCED" and rerun.
- To use the overview camera, set CAMERA_MODE = "OVERVIEW" near the top and run the script again.

ENGINEERING CSV OUTPUTS (generated when the script runs)
- HAPI_V13_<variant>_simulation_telemetry.csv: frame/time, pose, speed and yaw commands, left/right motor RPM, IR distances, wall clearance and collection state.
- HAPI_V13_<variant>_simulation_summary.csv: dimensions and assumptions/limits.
- HAPI_V13_<variant>_component_mass_current_budget.csv: known values and explicitly marked placeholders/unknowns.
- HAPI_V13_<variant>_mass_current_telemetry.csv: assumed mass/displacement and current proxy over time.

ASSUMPTIONS / LIMITS
- PETG is a provisional visual/material choice. Its density does not magically determine printed part weight; wall count, infill, hardware, and actual mass must be measured.
- 0.45 kg dry boat mass is a placeholder inherited from prior discussion, not a scale measurement.
- 2 x 80 W / 12 V implies about 13.33 A total nominal propulsion current ONLY if the 80 W rating is electrical input power. Add-ons use a rough 1.8 A allowance. Startup/stall current, driver losses, and actual motor data are not included.
- Do not assume an L298N is appropriate for the 775 motor option without checking its actual current ratings and thermal limits. Select the driver from the purchased motor's stall/current data.
- Battery capacity, mass, chemistry and continuous current limit are still unknown. Runtime is therefore not a validated output.
- Water surface waves, prop wash, foam and wakes are visual effects only. This is not CFD, not a Navier-Stokes solve, not a rigid-body fluid interaction model, and not a measured hydrodynamics simulation.
- The boat motion is a baked kinematic lawn-mower path; differential RPM values are derived from the path. Yaw/thrust calibration needs actual motor/propeller testing.
- Trash is represented with small visual meshes. Pickup is gated by a programmed intake proximity test and the item/mass caps, not a rigid-body contact solver.
- The HAPI wordmark is a text-based side decal approximation; inspect in Blender before the final render.
- The supplier URLs in the attached screenshot are too tiny to transcribe reliably here; no replacement links were invented.

FINAL VALIDATION BEFORE SUBMISSION
1. Run the script in your installed Blender version.
2. Inspect for floating/misaligned components, especially the conveyor intake, sensor pods, text decal, rudders and propeller clearances.
3. Check whether the actual motor and chosen driver can handle load/stall current.
4. Weigh the assembled model and enter actual dry mass/battery capacity in the generated CSV/assumption inputs.
5. Describe the scene honestly in the report as a controlled visual + kinematic simulation with engineering telemetry, not a validated CFD result.
